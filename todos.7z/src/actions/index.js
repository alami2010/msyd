export const setDisable = () => ({
  type: 'SET_DISABLE'
})


export const SET_DISABLE = (id) => ({
  type: 'personneClick',id
})


export const showAll = () => ({
  type: 'SHOW_ALL'
})


export const searchPersonne = (text) => ({
  type: 'SEARCH',
  text
})

