

const presentation = (state = {isok : false}, action) => {


  console.info(action);

  switch (action.type) {
    case 'SET_DISABLE':

        console.log(Object.assign({}, state, {
          isok: true
        }));
          return Object.assign({}, state, {
            isok: true
          });

    default:
      return state;
  }
}

export default presentation


