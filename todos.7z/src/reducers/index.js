import { combineReducers } from 'redux'
import personnes from './personnes'
import presentation from './presentation'

const personnesApp = combineReducers({
  presentation, personnes})

export default personnesApp
