const isContain = (string, substring) => {
  return string.toString().indexOf(substring) !== -1;
}


const  personnesDATA = [{
  id: 1,
  city: 'Istanbul',
  name: 'Vatanay Sara	'
},
  {
    id: 2,
    city: 'Istanbul',
    name: 'Burak Eric	'
  },
  {
    id: 3,
    city: 'London',
    name: 'Egemen Michael	'
  },
  {
    id: 4,
    city: 'Mardid',
    name: 'Egemen Michael	'
  }];

const personnes = (state = personnesDATA, action) => {

  console.info('action');

  console.info(action);

  switch (action.type) {
    case 'SHOW_ALL':
      return state;

    case 'SEARCH':
      return  personnesDATA.filter(function (el) {
      return isContain(el.id ,action.text) || isContain(el.name ,action.text) || isContain(el.city ,action.text)  ;
    });
    default:
      return state
  }
}

export default personnes


