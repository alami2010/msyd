import { connect } from 'react-redux'
import { setDisable } from '../../actions'
import TableResult from './TableResult'



const mapStateToProps = (state) => ({
  state : state,
  personnes: state.personnes,
  presentation: state.presentation
})

const mapDispatchToProps =  ({
  onPersonneClick: setDisable
})

const SearchBar = connect(
  mapStateToProps,
  mapDispatchToProps
)(TableResult)

export default SearchBar
