import React, { PropTypes } from 'react'

const TableResult = ({ personnes, onPersonneClick }) => (
    <table className="table table-hover table-bordered results">
        <thead>
        <tr>
            <th>#</th>
            <th className="col-md-5 col-xs-5">Name</th>
            <th className="col-md-3 col-xs-3">City</th>
        </tr>
        </thead>
        <tbody>


    {personnes.map(todo =>

    <tr key={todo.id}  onClick={() => onPersonneClick(todo.id)} >
        <th scope="row">{todo.id} </th>
        <td> {todo.name}</td>
        <td> {todo.city}</td>
    </tr>



    )}
        </tbody>
    </table>
)

/*TodoList.propTypes = {
  todos: PropTypes.arrayOf(PropTypes.shape({
    id: PropTypes.number.isRequired,
    completed: PropTypes.bool.isRequired,
    text: PropTypes.string.isRequired
  }).isRequired).isRequired,
  onTodoClick: PropTypes.func.isRequired
}*/

export default TableResult
