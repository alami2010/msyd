import React from 'react'
import TableResult from './TableSearchResult/TableResult.jsx'
import SearchBar from './SearchBar/searchBar.jsx'
import './App.css';


const App = () => (
  <div className="app">
    <SearchBar />
    <TableResult />
  </div>
)

export default App
