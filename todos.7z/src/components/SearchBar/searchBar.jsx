import { connect } from 'react-redux'
import { personneClick } from '../../actions'
import searchBar from './searchBar'



const mapStateToProps = (state) => ({
    state: state,
    presentation : state.presentation
})



const VisibleSearchBar = connect(
    mapStateToProps
)(searchBar)

export default VisibleSearchBar
