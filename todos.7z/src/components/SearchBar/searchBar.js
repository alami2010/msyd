import React from 'react'
import { connect } from 'react-redux'
import './searchBar.css';
import { searchPersonne } from '../../actions'


class SearchBar extends React.Component {

    constructor(props) {
        super(props);
        this.dispatch = props.dispatch;
        this.disabled = props.presentation.isok;
        this.state = props.state;
        console.info('xxxxxx');
        console.info(this);
        this.handleChange = this.handleChange.bind(this);

    }


    handleChange(event) {

        this.dispatch(searchPersonne(event.target.value))
    }

    handleClick(event) {

        console.info(this.state);
    }


    render() {
        return (



        <div className="row sreach-bar">
            <div className="col-md-8">
                <button type="button"  disabled={this.disabled}   onClick={() => {this.handleClick(this.disabled) }}  className="btn btn-default btn-lg active">Edit</button>
                <button type="button"  disabled={this.disabled} className="btn btn-default btn-lg active">Remove</button>
            </div>
            <div className="col-md-4">

                <input type="text"  onChange={this.handleChange} className="search form-control" placeholder="What you looking for?"/>
            </div>
        </div>



     );
    }


}



SearchBar = connect()(SearchBar)

export default SearchBar
