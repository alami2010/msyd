import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';
import Welcome from './Welcome';

import './index.css';

ReactDOM.render(
  <App />,
  document.getElementById('app')
);




/*
function tick() {
    const element = (
        <div>
        <h1>Hello, world!</h1>
    <h2>It is {new Date().toLocaleTimeString()}.</h2>
    </div>
);
    ReactDOM.render(
        element,
        document.getElementById('app')
    );
}

setInterval(tick, 1000);*/


/*

const element = <Welcome name="Sara" />;
ReactDOM.render(
    element,
    document.getElementById('app')
);*/
