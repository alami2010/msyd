import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MessageService } from './services/message.service';
import { MessageModel } from './model/message.model';
import { RequestModel } from '../api/model/request.model';
import { KeyValueModel } from '../api/model/keyvalue.model';


@Component({
    selector: 'l0010',
    templateUrl: './l0010_message.template.html',
})
export class L0010MessagesComponent {

    messages: MessageModel[];

    constructor(private route: ActivatedRoute) {
        this.route.data.forEach((data: {res: MessageModel[]}) => {
            this.messages = data.res;
        });
    }

}
