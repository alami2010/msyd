import { Resolve, ActivatedRouteSnapshot } from "@angular/router";
import { Injectable } from "@angular/core";
import "rxjs/add/operator/toPromise";
import { MessageService } from "./message.service";
import { MessageModel } from "../model/message.model";
import { AppState } from "../../app.service";
import { AsyncRequest } from "../../api/model/security/asyncrequest.model";

@Injectable()
export class MessageResolver implements Resolve<MessageModel> {
    constructor(private messageService: MessageService, private appState: AppState) {

    }

    resolve(route: ActivatedRouteSnapshot): Promise<MessageModel> {
        let requestModel: AsyncRequest<any> = this.appState[ 'requestModel' ];
        if (!requestModel) {
            requestModel = new AsyncRequest<any>();
            requestModel.viewId = 'L0010';
        }
        // noinspection TypeScriptUnresolvedFunction
        return this.messageService.allMessages(requestModel).toPromise().then(result => {
            return result;
        });
    }
}
