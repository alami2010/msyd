import { Component, ViewEncapsulation, OnInit, OnDestroy, ElementRef } from '@angular/core';
import { ViewModel } from './api/model/view.model';
import { EventsCommon } from './api/service/eventcommon.service';
import { PluginService } from './api/plugins/plugin.service';
import { ToasterConfig } from './api/toaster/toaster-config';
import { ViewCommon } from './api/service/viewcommon.service';
import { LoggingService } from './api/service/logging.service';
import { ToasterService } from './api/toaster/toaster.service';
import { AppState } from './app.service';
import { Router } from '@angular/router';

declare var $: any;

/*
 * App Component
 * VicRoads Registration and Licences Shell.
 */
@Component({
    selector: 'app',
    encapsulation: ViewEncapsulation.None,
    templateUrl: './app.template.html'
})
export class App extends ViewModel implements OnInit, OnDestroy {

    currentViewId: string;
    branchName: string;
    client: string;
    isLogged: boolean;
    menuShown: boolean;
    dateViewUpdate: Date;
    clientID: string;
    branchID: string;
    userId: string;

    public toasterconfig: ToasterConfig =
        new ToasterConfig({
            showCloseButton: true,
            tapToDismiss: false,
            positionClass: 'toast-bottom-full-width',
            timeout: {success: 20000}
        });

    constructor(public pluginService: PluginService,
                private router: Router,
                private eventsCommon: EventsCommon,
                viewCommon: ViewCommon,
                private el: ElementRef,
                private log: LoggingService,
                private toaster: ToasterService,
                private appState: AppState) {
        super();
        this.currentViewId = 'L0000';
        viewCommon.registerComponent(this);
        this.isLogged = true;
        this.menuShown = true;
        this.dateViewUpdate = new Date();

        // window.onbeforeunload = function (e) {
        //     return 'Dialog text here.';
        // };
    }

    ngOnInit() {
        this.log.debug('Shell init');

        // Displays clock in the footer.
        // this.pluginService.jClock();

        // Register event listeners for updating footer and header.
        this.eventsCommon.on(EventsCommon.UPDATE_VIEW_ID, data => {
            this.currentViewId = data;
            this.dateViewUpdate = new Date();
        });
        this.eventsCommon.on(EventsCommon.UPDATE_BRANCH, data => this.branchName = data);
        this.eventsCommon.on(EventsCommon.UPDATE_CLIENT, data => this.client = data);
        // Update login.
        this.eventsCommon.on(EventsCommon.UPDATE_LOGIN, data => this.isLogged = data);
        // Update user.
        this.eventsCommon.on(EventsCommon.UPDATE_USER, data => this.userId = data);
        // Pop an error message.
        this.eventsCommon.on(EventsCommon.POP_ERROR, data => {
            this.toaster.pop('error', data.title, data.message);
        });
        // Pop a success message.
        this.eventsCommon.on(EventsCommon.POP_SUCCESS, data => {
            this.toaster.pop('success', data.title, data.message);
        });

        if (this.appState[ 'clientID' ]) {
            this.clientID = this.appState[ 'clientID' ];
        } else {
            this.clientID = '';
        }
        if (this.appState[ 'branchID' ]) {
            this.branchID = this.appState[ 'branchID' ];
        } else {
            this.branchID = null;
        }

        return undefined;
    }

    ngAfterViewInit() {
        // Manual redirect on login view.
        if (!this.isLogged) {
            this.log.debug('Is logged?', this.isLogged);
            this.router.navigate(['l0009_login']);
        }
    }

    ngOnDestroy() {
        console.log('clean up app');
    }

    showHideNavigation() {
        if (this.menuShown) {
            this.menuShown = false;
            $('#rd_col00').addClass('hidden');
            $('#rd_fxcol00').toggleClass('active');
            $('#rd_fxcol00 i').removeClass('fa-check-square').addClass('fa-square');
            $('#rd_col01').removeClass('col-sm-8 col-sm-push-4 ' +
                'col-md-9 col-md-push-3 col-lg-10 col-lg-push-2').addClass('col-sm-12');
        } else {
            this.menuShown = true;
            $('#rd_col00').removeClass('hidden');
            $('#rd_fxcol00').toggleClass('active');
            $('#rd_fxcol00 i').removeClass('fa-square').addClass('fa-check-square');
            $('#rd_col01').removeClass('col-sm-12').addClass('col-sm-8 col-sm-push-4 ' +
                'col-md-9 col-md-push-3 col-lg-10 col-lg-push-2');
        }
    }
}
