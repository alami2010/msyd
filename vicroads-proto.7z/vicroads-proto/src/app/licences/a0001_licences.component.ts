import { Component, OnInit, AfterViewInit } from '@angular/core';
import { ViewModel } from '../api/model/view.model';
import { ViewCommon } from '../api/service/viewcommon.service';

/**
 * This is an abstract view it should not be called directly.
 */
@Component({
    selector: 'A0001',
    template: '<router-outlet></router-outlet>'
})
export class A0001LicencesComponent extends ViewModel implements OnInit, AfterViewInit {

    constructor(private viewCommon: ViewCommon) {
        super();
        this.id = 'A0001';
        this.viewCommon.registerComponent(this);
    }

    ngOnInit() {
    }

    ngAfterViewInit() {
    }
}
