import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { AppState } from '../../app.service';
import { ClientFindService } from '../client/search/services/clientfind.service';
import { BranchService } from './branch.service';

@Injectable()
export class LicencesResolver implements Resolve<any> {
    constructor(private router: Router,
                private appState: AppState,
                private findService: ClientFindService,
                private branchService: BranchService) {
    }

    resolve(route: ActivatedRouteSnapshot,
            state: RouterStateSnapshot): Observable<any>|Promise<any>|any {
        // point of entry... we set the URL with parameters.
        this.appState[ 'paramsBranchId' ] = route.url[ 1 ] ? route.url[ 1 ].path : '';
        this.appState[ 'paramsClientId' ] = route.url[ 2 ] ? route.url[ 2 ].path : '';
        let hasBranch: boolean = true;
        for (let p in route.params) {
            if (route.params[ p ]) {
                console.log('LicencesResolver', p, route.params[ p ]);
            }
        }
        if (route.params[ 'clientId' ]) {
            let clientId: number = +route.params[ 'clientId' ];
            if (clientId > 0) {
                this.findService.loadClient(route.params[ 'clientId' ], null);
            }
        }
        if (route.params[ 'branchId' ]) {
            let branchId: number = +route.params[ 'branchId' ];
            if (branchId !== 0) {
                this.branchService.loadBranchById(route.params[ 'branchId' ]);
            } else {
                hasBranch = false;
            }
        } else {
            hasBranch = false;
        }

        // noinspection TypeScriptUnresolvedFunction
        return Observable.of({hasBranch: hasBranch});
    }
}
