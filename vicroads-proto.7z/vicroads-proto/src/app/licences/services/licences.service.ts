import { Input } from '@angular/core';
import { NodeModel, NodeType } from '../../api/navigation/model/node.model';
import { NodeService } from '../../api/navigation/services/node.service';
import { DataStoreService } from '../../api/service/datastore.service';
import { L0004LicencesModel } from '../model/l0004_licences.model';
import { ClientFindService } from '../client/search/services/clientfind.service';

declare var $: any;
declare var jQuery: any;

@Input()
export class LicencesService {

    constructor(private nodeService: NodeService,
                private dataStoreService: DataStoreService,
                private findService: ClientFindService) {

    }

    public selectStateInView(nodes: NodeModel[]): void {
        this.nodeService.selectStateInView(nodes[ 0 ].parent, null);
    }

    /**
     * Expand the tree view to client find and disable the rest of the tree.
     */
    public selectClientSearch(view: L0004LicencesModel, clientID: string) {
        console.log('Checking client...', this.dataStoreService.client);
        if (clientID && clientID !== '0') {
            this.findService.loadClient(clientID, null);
        }
        if (this.dataStoreService.client.id === '0') {
            /*
             Disabled all navigation tree's node but keep the following nodes active.
             NODE: _NTV_R_C0 _name: Client
             NODE: _NTV_R_C0S1 _name: Search
             NODE: _NTV_R_C0S1I0 _name: Identity
             NODE: _NTV_R_C0S1P1 _name: Person
             NODE: _NTV_R_C0S1O2 _name: Organization
             */
            console.log('Disabling tree');
            this.nodeService.disableAllNodeBut([ '_NTV_R_C0',
                '_NTV_R_C0S1',
                '_NTV_R_C0S1I0',
                '_NTV_R_C0S1P1',
                '_NTV_R_C0S1O2' ], view.navigationTree.treeNodes);
        }
    }

    public enablesAllNode(view: L0004LicencesModel) {
        console.log('Navigation Tree View Enable all nodes');
        this.nodeService.enableAllNodes(view.navigationTree.treeNodes);
    }

    /**
     * Builds the data nodes Navigation Tree View for licences
     * @returns {NodeModel[]}
     */
    public buildTreeView(rootPath: string[]): NodeModel[] {
        // Reference is maintained by the parent.
        let rootNode: NodeModel = new NodeModel();
        rootNode.type = NodeType.ROOT;
        rootNode.rootPath = rootPath;

        // Client.
        let nclient: NodeModel = this.nodeService.addNode('Client', NodeType.NODE, null, rootNode);
        this.nodeService.addNode('New', NodeType.LEAF, null, nclient);
        let nsearch: NodeModel = this.nodeService.addNode('Search', NodeType.NODE, null, nclient);
        this.nodeService.addNode('Identity', NodeType.LEAF, 'l0005identity', nsearch);
        this.nodeService.addNode('Person', NodeType.LEAF, 'l0006person', nsearch);
        this.nodeService.addNode('Organization', NodeType.LEAF, 'l0007organization', nsearch);
        this.nodeService.addNode('Maintain', NodeType.LEAF, 'l0008maintain', nclient);

        // Appointment Book.
        let abook: NodeModel = this.nodeService.addNode('Appointment book',
            NodeType.NODE, null, rootNode);
        this.nodeService.addNode('Identity', NodeType.LEAF, 'l0007organization', abook);
        this.nodeService.addNode("Open 'Branch'", NodeType.LEAF, 'l0007organization', abook);
        this.nodeService.addNode('Print Reports', NodeType.LEAF, 'l0007organization', abook);

        // Appointment
        let apptmnt: NodeModel = this.nodeService.addNode('Appointment',
            NodeType.NODE, null, rootNode);
        this.nodeService.addNode('New', NodeType.LEAF, 'l0007organization', apptmnt);
        this.nodeService.addNode('Open', NodeType.LEAF, 'l0007organization', apptmnt);
        this.nodeService.addNode("Today's appointment", NodeType.LEAF,
            'l0007organization', apptmnt);
        this.nodeService.addNode('Browse', NodeType.LEAF, 'l0007organization', apptmnt);
        this.nodeService.addNode('View Hold', NodeType.LEAF, 'l0007organization', apptmnt);

        this.nodeService.addNode('PaymentCollection', NodeType.NODE, null, rootNode);
        this.nodeService.addNode('Stock', NodeType.NODE, null, rootNode);
        this.nodeService.addNode('PCS Audit Log', NodeType.NODE, null, rootNode);
        this.nodeService.addNode('Licence', NodeType.LEAF, null, rootNode);
        this.nodeService.addNode('Test Results', NodeType.LEAF, null, rootNode);
        this.nodeService.addNode('Interstate', NodeType.LEAF, null, rootNode);
        this.nodeService.addNode('Extracts', NodeType.NODE, null, rootNode);
        this.nodeService.addNode('Demerit Points', NodeType.LEAF, null, rootNode);
        this.nodeService.addNode('TIN', NodeType.NODE, null, rootNode);
        this.nodeService.addNode('TIN Reversals', NodeType.NODE, null, rootNode);
        this.nodeService.addNode('Non Demerit Point TIN', NodeType.NODE, null, rootNode);
        this.nodeService.addNode('Ban', NodeType.LEAF, null, rootNode);
        this.nodeService.addNode('Re-Licencing Conditions', NodeType.NODE, null, rootNode);
        this.nodeService.addNode('CourtEvent', NodeType.NODE, null, rootNode);
        this.nodeService.addNode('Medical Review', NodeType.LEAF, null, rootNode);
        this.nodeService.addNode('Office', NodeType.NODE, null, rootNode);
        this.nodeService.addNode('Standard Letters', NodeType.LEAF, null, rootNode);
        this.nodeService.addNode('Parameters', NodeType.NODE, null, rootNode);
        this.nodeService.addNode('Archive Catalogue', NodeType.LEAF, null, rootNode);
        this.nodeService.addNode('Boat Licence', NodeType.LEAF, null, rootNode);
        this.nodeService.addNode('Boat Licence Ban', NodeType.LEAF, null, rootNode);
        this.nodeService.addNode('Maintain Optimized Fields', NodeType.NODE, null, rootNode);

        return rootNode.children;
    }

    public menuBehavior() {
        /* collapse logic II */
        if ($('#rd_fxcol00').hasClass('active')) {
            $('#rd_col00').removeClass('hidden');
            $('#rd_col01').removeClass('col-sm-12')
                .addClass('col-sm-8 col-sm-push-4 col-md-9' +
                    ' col-md-push-3 col-lg-10 col-lg-push-2');
        } else {
            $('#rd_col00').addClass('hidden');
            $('#rd_col01')
                .removeClass('col-sm-8 col-sm-push-4 col-md-9' +
                    ' col-md-push-3 col-lg-10 col-lg-push-2')
                .addClass('col-sm-12');
        }
    }

    selectNavigationFind(view: L0004LicencesModel, url?: string) {
        if (url && view.navigationTree.treeNodes) {
            console.log('Tree view Select state in view', url);
            this.nodeService.selectStateInView(
                view.navigationTree.treeNodes[ 0 ],
                url);
        } else {
            console.log('Tree view not initialized');
        }
        // if (!view.navigationTree.treeNodes) {
        //     console.log('Tree view not initialized');
        // } else {
        //     this.nodeService.selectIdInView(view.navigationTree.treeNodes[ 0 ],
        //         '_NTV_R_C0M2');
        // }
    }
}

export const CLIENT_SERVICE_PROVIDER: any[] = [ NodeService, LicencesService ];
