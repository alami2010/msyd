import { Injectable } from '@angular/core';
import { NodeService } from '../../../../../api/navigation/services/node.service';
import { TabService } from '../../../../../api/elements/service/tabs.service';
import { NodeModel, NodeType } from '../../../../../api/navigation/model/node.model';
import { T0010TradingIdentity } from '../t0010_tradingidentity.component';
import { LoggingService } from '../../../../../api/service/logging.service';

@Injectable()
export class IdentityService {
    constructor(private nodeService: NodeService,
                private tabService: TabService,
                private log: LoggingService) {

    }

    loadTreeView(view: T0010TradingIdentity) {
        let rootNode: NodeModel = new NodeModel();
        rootNode.type = NodeType.ROOT;

        // Client.
        let nroot: NodeModel = this.nodeService
            .addNodeParameter('Demerit Points (Current)',
                NodeType.FOLDER,
                null,
                rootNode,
                null,
                view.displayButtons);
        let ngroup: NodeModel = this.nodeService
            .addNodeParameter('Groups',
                NodeType.GROUP_ONE,
                null,
                nroot,
                null,
                view.displayButtons);
        let nsuspension: NodeModel = this.nodeService
            .addNodeParameter('23: Suspension Pending 3',
                NodeType.GROUP_TWO,
                'd0013group',
                ngroup,
                null,
                view.displayButtons);

        this.nodeService
            .addNodeParameter('2: 3/11/2015', NodeType.GROUP_THREE,
                'd0014demerit',
                nsuspension,
                '2015113-2',
                view.displayButtons);
        this.nodeService
            .addNodeParameter('1: 14/09/2015',
                NodeType.GROUP_THREE,
                'd0014demerit',
                nsuspension,
                '20151409-1',
                view.displayButtons);
        this.nodeService
            .addNodeParameter('2: 2/2/2015',
                NodeType.GROUP_THREE,
                'd0014demerit',
                nsuspension,
                 '20150202-2',
                view.displayButtons);

        this.nodeService
            .addNodeParameter('Ungrouped',
                NodeType.FOLDER,
                null,
                rootNode,
                null,
                view.displayButtons);
        this.nodeService
            .addNodeParameter('Demerit Points (Historical)',
                NodeType.GROUP_FOUR,
                null,
                rootNode,
                null,
                view.displayButtons);
        console.log('Demerit Points loaded');
        view.ntvDemeritPoints.treeNodes = rootNode.children;
        this.nodeService.expandAllNodes(view.ntvDemeritPoints.treeNodes);
        this.log.debug('Render navigation button invisible', view.btnAddBan);
        view.btnAddBan.visible = false;
        view.btnToHistorical.visible = false;
        view.btnButton.visible = false;
    }
}

export const IDENTITY_SERVICE_PROVIDER: any[] = [ NodeService, IdentityService ];

