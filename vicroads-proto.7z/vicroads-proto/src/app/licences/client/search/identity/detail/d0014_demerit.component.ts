import { Component } from '@angular/core';
import { ViewModel } from '../../../../../api/model/view.model';
import { ViewCommon } from '../../../../../api/service/viewcommon.service';
import { TitleBlockComponent } from '../../../../../api/elements/titleblock.component';
import { ActivatedRoute } from '@angular/router';

@Component({
    selector: 'd0013-group',
    template: '<rnl-block-title title="Demerit Point"></rnl-block-title><p>...{{dpointId}}...</p>',
})
export class D0014Demerit extends ViewModel {
    dpointId: string;

    constructor(viewCommon: ViewCommon, private route: ActivatedRoute) {
        super();
        this.id = 'D0014';
        viewCommon.registerComponent(this);
    }

    ngOnInit() {
        this.dpointId = this.route.snapshot.params[ 'dpointId' ];
        // Changing the param do not re-instantiate the view/component
        // We need to watch the parameter.
        this.route.params.subscribe(() =>
            this.route.params.forEach(p => this.dpointId = p[ 'dpointId' ]));

        console.log('Demerit', this.dpointId);
    }
}
