import { Component } from '@angular/core';
import { ViewModel } from '../../../../api/model/view.model';
import { ViewCommon } from '../../../../api/service/viewcommon.service';

@Component({
    selector: 't0012-alias-name',
    templateUrl: './t0012_aliasname.template.html'
})
export class T0012AliasName extends ViewModel {
    constructor(viewCommon: ViewCommon) {
        super();
        this.id = 'T0012';
        viewCommon.registerComponent(this);
    }
}
