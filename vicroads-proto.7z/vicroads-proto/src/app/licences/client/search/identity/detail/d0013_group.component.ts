import { Component } from '@angular/core';
import { ViewModel } from '../../../../../api/model/view.model';
import { ViewCommon } from '../../../../../api/service/viewcommon.service';
import { TitleBlockComponent } from '../../../../../api/elements/titleblock.component';

@Component({
    selector: 'd0013-group',
    template: '<rnl-block-title title="Group"></rnl-block-title>',
})
export class D0013Group extends ViewModel {
    constructor(viewCommon: ViewCommon) {
        super();
        this.id = 'D0013';
        viewCommon.registerComponent(this);
    }
}
