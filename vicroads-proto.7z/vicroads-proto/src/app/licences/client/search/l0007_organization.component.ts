import { Component, OnInit } from '@angular/core';
import { ViewCommon } from '../../../api/service/viewcommon.service';
import { ViewModel } from '../../../api/model/view.model';

@Component({
    selector: 'l0007-selector',
    templateUrl: './l0007_organization.template.html'
})
export class L0007OrganizationComponent extends ViewModel implements OnInit {

    constructor(private viewCommon: ViewCommon) {
        super();
        this.id = 'L0007';
    }

    ngOnInit() {
        this.viewCommon.registerComponent(this);
    }

}
