import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ViewCommon } from '../../../api/service/viewcommon.service';
import { L0006PersonModel } from './model/l0006_person.model';
import { StateService } from 'ui-router-ng2/ng2';
import { PluginService } from '../../../api/plugins/plugin.service';
import { DataStoreService } from '../../../api/service/datastore.service';
import { ClientFindService } from './services/clientfind.service';
import { EventsCommon } from '../../../api/service/eventcommon.service';

@Component({
    selector: 'l0006-selector',
    templateUrl: './l0006_person.template.html',
})
export class L0006PersonComponent extends L0006PersonModel implements OnInit {

    constructor(viewCommon: ViewCommon,
                private router: Router,
                private findService: ClientFindService,
                private pluginService: PluginService,
                private dataStore: DataStoreService,
                private eventCommon: EventsCommon) {
        super();
        this.id = 'L0006'; // View ID.
        viewCommon.registerComponent(this); // Build the view instance.
    }

    ngOnInit() {
        // Set button open disabled.
        this.btnOpen.enabled = false;
        this.dtgPerson.list = []; // make sure data grid rows are emptied.
        // Defines grid headers
        this.dtgPerson.headers = [ 'Client ID', 'Status', 'POI', 'Name', 'DOB', 'Suburb/Location' ];
        // Defines column properties.
        this.dtgPerson.rowProperties = [ 'id', 'status', 'poi', 'name', 'dob', 'location' ];
        // Skin for checkboxes and radio buttons
        this.pluginService.icheckInit();
    }

    /**
     * In this sample findClientByCriteria is mocked
     * returning only sample data.
     */
    findByCriteria() {
        this.findService.findClientByCriteria(this); // Call search service.
        this.btnOpen.enabled = true; // We assume the find service has returned result.
        this.dtgPerson.focused = true; // Set the focus on the data grid.
    }

    openClient() {
        console.log('Loading client....');
        this.findService.enableNavigationTree();
        this.findService.loadClient(this.dtgPerson.rowSelect.id, this);
        this.dataStore.client.id = this.dtgPerson.rowSelect.id;
        this.router.navigate(['l0004licences',
            this.dataStore.branch.id,
            this.dataStore.client.id,
            'l0008maintain']);
    }
}
