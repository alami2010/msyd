import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { AppState } from '../../../../app.service';

@Injectable()
export class IdentityResolver implements Resolve<any> {
    constructor(private router: Router, private appState: AppState) {
    }

    resolve(route: ActivatedRouteSnapshot,
            state: RouterStateSnapshot): Observable<any>|Promise<any>|any {
        console.log('IdentityResolver URL', route.url);
        this.appState[ 'paramsBranchId' ] = route.url[1] ? route.url[1] : '';
        this.appState[ 'paramsClientId' ] = route.url[2] ? route.url[2] : '';
        return undefined;
    }
}
