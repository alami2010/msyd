import { Injectable } from '@angular/core';
import { NodeService } from '../../../../api/navigation/services/node.service';
import { L0005IdentityModel } from '../model/l0005_identity.model';
import { TabService } from '../../../../api/elements/service/tabs.service';
import { TabItem } from '../../../../api/model/tablist.model';

@Injectable()
export class IdentityService {

    constructor(private tabService: TabService) {

    }

    loadTreeView(view: L0005IdentityModel) {
        // First Root level tab
        let tabRoot: TabItem = new TabItem();
        // First Tab level identity
        let tabIdentity: TabItem =
            this.tabService.addTab('Trading name', null, 'Trading name inline help', tabRoot);
        // Second Tab level 'Trading name'
        this.tabService.addTab('Trading person',
            't0009tradingperson',
            'Trading person inline help',
            tabIdentity);
        this.tabService.addTab('Trading Identity',
            't0010tradingidentity',
            'Trading identity inline help',
            tabIdentity);
        this.tabService.addTab('Trading Driver',
            't0011tradingdriver',
            'Trading driver inline help',
            tabIdentity);
        // First lvl and only tab level 'Alias _name'
        this.tabService.addTab('Alias Name',
            't0012aliasname',
            'Trading person inline help',
            tabRoot);
        // First lvl Client Alert
        let tabClientAlert = this.tabService.addTab('Client Alert',
            null,
            'Client Alert inline help',
            tabRoot);
        // Second lvl Client Alert
        this.tabService.addTab('Client Alert Info',
            'l0006person',
            'Client Alert Info inline help',
            tabClientAlert);
        this.tabService.addTab('Some other',
            'l0006person',
            'Client Alert Info inline help',
            tabClientAlert);
        this.tabService.addTab('Another client',
            'l0006person',
            'Client Alert Info inline help',
            tabClientAlert);

        view.tbgTest.tabList = tabRoot.children;
    }

}

export const PERSON_SERVICE_PROVIDER: any[] = [ NodeService, IdentityService ];
