import { Injectable } from '@angular/core';
import { EventsCommon } from '../../../../api/service/eventcommon.service';
import { DataStoreService } from '../../../../api/service/datastore.service';
import { L0006PersonModel } from '../model/l0006_person.model';
import { ClientModel } from '../../../../api/model/domain/client.model';
import { Http, RequestOptions, Headers } from '@angular/http';
import { Observable } from 'rxjs';
import { AsyncRequest } from '../../../../api/model/security/asyncrequest.model';
import { ViewCommon } from '../../../../api/service/viewcommon.service';

@Injectable()
export class ClientFindService {

    constructor(private eventsCommon: EventsCommon,
                private dataStore: DataStoreService,
                private http: Http,
                private viewCommon: ViewCommon) {

    }

    public enableNavigationTree() {
        this.eventsCommon.broadcast(EventsCommon.UPDATE_NAVIGATION_TREE, 'enable-all');
    }

    public loadClient(clientID: string, view: L0006PersonModel) {
        this.dataStore.client.id = clientID;
        if (view !== null) {
            for (let client of view.dtgPerson.list) {
                if (client.id === clientID) {
                    this.dataStore.client.name = client._name;
                    break;
                }
            }
            let clientData = this.dataStore.client.id + ' - ' + this.dataStore.client.name;
            console.log('Found client... ', clientData);
            this.eventsCommon.broadcast(EventsCommon.UPDATE_CLIENT, clientData);
        } else {
            console.log('NOT FOUND......', view);
            // fire a find by id.
            this.findById(clientID).subscribe(data => {
                this.dataStore.client.name = data.name;
                let clientData = this.dataStore.client.id + ' - ' + this.dataStore.client.name;
                console.log('Found client... ', clientData);
                this.eventsCommon.broadcast(EventsCommon.UPDATE_CLIENT, clientData);
            });
        }

    }

    /**
     * Mock service.
     * @param view
     */
    findClientByCriteria(view: L0006PersonModel) {
        this.allClients().subscribe(res => {
            view.dtgPerson.list = res;
            console.log('Loading clients...');
        });
    }

    /**
     * Back end calls update
     */
    public allClients(): Observable<ClientModel[]> {
        let headers = new Headers({'Content-Type': 'application/json'});
        let options = new RequestOptions({headers: headers});
        let req: AsyncRequest<any> = new AsyncRequest();
        req.viewId = this.viewCommon.getCurrentView().id;
        // noinspection TypeScriptUnresolvedFunction
        return this.http.post('/api/secure/allclients', JSON.stringify(req), options)
            .map(res => res['data']);
    }

    /**
     * Back end calls update
     */
    public findById(id: string): Observable<ClientModel> {
        let headers = new Headers({'Content-Type': 'application/json'});
        let options = new RequestOptions({headers: headers});
        let req: AsyncRequest<string> = new AsyncRequest<string>();
        req.viewId = this.viewCommon.getCurrentView().id;
        req.data = id;
        req.auditInformation = window.navigator.userAgent;
        console.log('View ID', req.viewId);
        // noinspection TypeScriptUnresolvedFunction
        return this.http.post('/api/secure/findbyid', JSON.stringify(req), options)
            .map(res => res['data']);
    }

}
