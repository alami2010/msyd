import { ViewModel } from '../../../../api/model/view.model';
import { TabElement } from '../../../../api/model/tab.element';

export class L0005IdentityModel extends ViewModel {
    tbgTest: TabElement;
}
