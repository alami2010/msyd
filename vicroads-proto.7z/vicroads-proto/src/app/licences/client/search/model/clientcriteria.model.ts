export class ClientCriteria {
    searchFor: string;
    surname: string;
}
