import { AsyncMessage } from './asyncmessage.model';

export class AsyncResult<T> {
    data: T;
    message: AsyncMessage[];
}
