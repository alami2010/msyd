export class KeyValueModel {
  key:any;
  value:string;
}
