import { ViewElement } from './view.element';
import { Output, EventEmitter } from '@angular/core';

export class ViewFocusedElement extends ViewElement {
    tabIndex: number;
    focused: boolean;

    @Output()
    focusEvent: EventEmitter<any> = new EventEmitter(false);

    constructor() {
        super();
        this.tabIndex = 0;
        this.focused = false;
    }
}
