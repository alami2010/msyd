import { ViewFocusedElement } from './viewfocus.element';

export class LinkElement extends ViewFocusedElement {
    link: string;

    constructor() {
        super();
        this.link = '';
    }
}
