import { ViewFocusedElement } from './viewfocus.element';

export class ButtonElement extends ViewFocusedElement {

    private static PRIMARY: string = 'btn-primary';
    private static DEFAULT: string = 'btn-default';

    /**
     * Return true if the button is a primary action.
     * @returns {boolean}
     */
    public get primary(): boolean {
        return this.classList.indexOf(ButtonElement.PRIMARY) > 0;
    }

    /**
     * Set primary button.
     * @param value
     */
    public set primary(value: boolean) {
        let idx: number = this.classList.indexOf(ButtonElement.PRIMARY);
        if (value) {
            if (idx === -1) {
                this.classList.push(ButtonElement.PRIMARY);
            }
        } else {
            if (idx > 0) {
                this.classList.splice(idx);
            }
        }
    }

    /**
     * Return true if button is default.
     * @returns {boolean}
     */
    public get default(): boolean {
        return this.classList.indexOf(ButtonElement.DEFAULT) > 0;
    }

    /**
     * set default button.
     * @param value
     */
    public set default(value: boolean) {
        let idx: number = this.classList.indexOf(ButtonElement.DEFAULT);
        if (value) {
            if (idx === -1) {
                this.classList.push(ButtonElement.DEFAULT);
            }
        } else {
            if (idx > 0) {
                this.classList.splice(idx);
            }
        }
    }

    constructor() {
        super();
        this.classList.push('btn');
    }

}
