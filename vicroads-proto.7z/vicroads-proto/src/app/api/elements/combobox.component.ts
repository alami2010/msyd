import {Component, ElementRef, Input, forwardRef, NgModule, Output, EventEmitter} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ViewCommon } from '../service/viewcommon.service';
import { LoggingService } from '../service/logging.service';
import { DomHandler } from '../service/domhandler.service';
import { AutoComplete, AutoCompleteModule } from './autocomplete/autocomplete.component';
import { ViewListValidation } from '../model/viewlistvalidation.element';
import { ValidationService } from './service/validation.service';
import { KeyValueModel } from '../model/keyvalue.model';
import { NG_VALUE_ACCESSOR, ControlValueAccessor } from '@angular/forms';
import {ViewElement} from "../model/view.element";

export const CBX_VALUE_ACCESSOR: any = {
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => ComboBoxComponent),
    multi: true
};

@Component({
    selector: 'rnl-combobox',
    templateUrl: './combobox.template.html',
    providers: [ CBX_VALUE_ACCESSOR ,{provide: ViewElement, useExisting: forwardRef(() => ComboBoxComponent) }]
})
export class ComboBoxComponent extends ViewListValidation implements ControlValueAccessor {

    labelClass: string;
    divInputClass: string;
    inlineHelp: string;
    inputId: string;
    @Input()
    placeholder: string;
    @Input()
    generalCol: number;
    input: HTMLInputElement;
    @Input()
    label: string;
    @Input()
    enabled: boolean = true;
    @Input()
    value: any;
    valueKey: any;
    suggestions: KeyValueModel[];
    oldValue: string;

    @Output()
    onError: EventEmitter<any> = new EventEmitter();

    onModelChange: Function = (value: any) => {
    };
    onModelTouched: Function = () => {
    };

    constructor(private el: ElementRef,
                private viewCommon: ViewCommon,
                private log: LoggingService,
                private dom: DomHandler,
                private validationService: ValidationService) {
        super();
        this.id = this.el.nativeElement.id;
        this.viewCommon.registerComponentElement(this);
        this.classList.push('form-group');
        this.classList.push('clearfix');
        this.labelClass = 'control-label';
        if (!this.inlineHelp) this.inlineHelp = '';
        this.inputId = this.id + 'Input';
        this.placeholder = '';
    }

    ngOnInit() {
        this.divInputClass = '';
        this.input = this.dom.findSingle(this.el.nativeElement, 'input');
        this.log.debug('Single', this.input);
        if (!this.generalCol || this.generalCol === 0) {
            this.generalCol = 3;
        }
        this.labelClass += ' col-md-' + this.generalCol;
        this.divInputClass += ' col-md-' + this.generalCol;
    }

    onFocus(e: any) {
        console.log('Focused receieved', this.id);
        this.classList.push('combo-box-focused');
    }

    onBlur(e: any) {
        let idx: number = this.classList.indexOf('combo-box-focused');
        if (idx >= 0) this.classList.splice(idx);
    }

    search(e: any) {
        if (e.query !== '') {
            this.suggestions = [];
            this.log.debug('Search', e, this.list);
            if (this.list) {
                for (let p of this.list) {
                    if (p.value.startsWith(e.query)) {
                        this.suggestions.push(p);
                    }
                }
            }
        } else {
            this.suggestions = this.list.slice();
        }
    }

    onSelectAuto(value: KeyValueModel) {
        this.value = value;
        if (value) this.onModelChange(value.key);
        this.log.debug('onSelect', value);
        this.changeValue();
    }

    /**
     * On control value change or key
     * down check the validity of the value.
     */
    changeValue() {
        this.log.debug('Selected value', this.value, this.oldValue);
        this.validationService.validate(this);
        this.oldValue = this.value;
        this.log.debug('Validation', this.validation, String(this.value));
    }

    writeValue(value: any): void {
        if (value) this.valueKey = value;
        this.list.forEach((v) => {
            if (v.key === value) {
                this.value = v;
            }
        });
    }

    registerOnChange(fn: Function): void {
        this.onModelChange = fn;
    }

    registerOnTouched(fn: Function): void {
        this.onModelTouched = fn;
    }
}

@NgModule({
    imports: [AutoCompleteModule, CommonModule, FormsModule],
    exports: [ComboBoxComponent],
    declarations: [ComboBoxComponent]
})
export class ComboBoxModule { }
