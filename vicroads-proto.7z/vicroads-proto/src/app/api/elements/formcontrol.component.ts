import {Component, ElementRef, Input, NgModule, EventEmitter, Output, ContentChildren, forwardRef} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ViewCommon } from '../service/viewcommon.service';
import { LoggingService } from '../service/logging.service';
import { DomHandler } from '../service/domhandler.service';
import { Validation, ValidationType } from '../model/validation.model';
import { ViewValidation } from '../model/viewvalidation.element';
import { ValidationService } from './service/validation.service';
import {TextBoxComponent} from "./textbox.component";
import {ComboBoxComponent} from "./combobox.component";
import {ViewElement} from "../model/view.element";

@Component({
    selector: 'rnl-form-control',
    template: `
    <div [attr.class]="classes" [ngClass]="{'has-error': hasError}">
      <label [attr.class]="labelClass" [attr.for]="inputId">
        <abbr *ngIf="inlineHelp !== ''" [attr.title]="inlineHelp">{{label}}</abbr>
        <span *ngIf="inlineHelp === ''">{{label}}</span>
        <span *ngIf="required">*</span>
       </label>
     <ng-content></ng-content>
    </div>
  `,
  providers: [TextBoxComponent,ComboBoxComponent]//,{provide: ViewElement, useExisting: forwardRef(() => TextBoxComponent) },{provide: ComboBoxComponent, useExisting: forwardRef(() => TextBoxComponent) }]
})
export class FormControlComponent extends ViewValidation {
    labelClass: string;
    divInputClass: string;
    inputClass: string;
    @Input()
    generalCol: number;
    @Input()
    label: string;
    @Input()
    inlineHelp: string;
    @Input()
    placeholder: string;
    inputId: string;
    required: boolean;
    pristine: boolean;
    @Input()
    hasError: boolean;
    @Output()
    onError: EventEmitter<any> = new EventEmitter();
    oldValue: any;
    input: HTMLInputElement;

  @ContentChildren(ViewElement,{descendants: true}) childs;
    /**
     * Text box component
     * @param el
     * @param viewCommon
     * @param log
     */
    constructor(private el: ElementRef,
                private viewCommon: ViewCommon,
                private log: LoggingService,
                private dom: DomHandler,
                private validationService: ValidationService) {
        super();
        this.id = el.nativeElement.id;
        this.viewCommon.registerComponentElement(this);
        this.classList.push('form-group');
        this.labelClass = 'control-label';
        if (!this.inlineHelp) this.inlineHelp = '';
        this.inputId = this.id + 'Input';
        this.inputClass = 'form-control';
        this.placeholder = '';
    }

    ngOnInit() {
        this.divInputClass = '';
        this.input = this.dom.findSingle(this.el.nativeElement, 'input');
        this.log.debug('Single', this.input);
        if (this.generalCol > 0) {
            this.labelClass += ' col-md-' + this.generalCol;
            this.divInputClass += ' col-md-' + this.generalCol;
        }


    }

  ngAfterContentInit() {
      if(this.childs && this.childs.length>1){
        let firstChild:ViewElement=this.childs.toArray()[0];
        this.inputId = firstChild.id;// + 'Input';
        console.log('Childs: ', firstChild);
        if(this.childs.length==1) {
          firstChild.onError.subscribe(
            (value: boolean) => {
              this.hasError = value;
              console.log("KKH hasError CHANGED", value);
            });//TODO unsubscribe
        }
      }
 /*   Object.observe(this, function(changes) {
      //is triggering
      console.log(changes);
    });*/

    console.log('Childs: ', this.childs);
  }

    ngAfterViewInit() {

    }



    /**
     * On control value change or key
     * down check the validity of the value.
     */
    changeValue() {
        let value: string = this.input.value;
        setTimeout(() => {
            if (this.value !== this.oldValue) {
                this.validationService.validate(this);
                this.onError.emit(this.hasError);
            }
        }, 0);
        this.oldValue = this.value;
        this.log.debug('Validation', this.validation, String(this.value));
    }

}

@NgModule({
    declarations: [ FormControlComponent ],
    exports: [ FormControlComponent ],
    imports: [ CommonModule, FormsModule ]
})
export class FormControlModule {
}
