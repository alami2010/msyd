import {
    Component,
    ElementRef,
    OnInit,
    HostListener,
    AfterViewInit,
    NgModule
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { ViewDataGridElement } from '../model/viewdatagrid.element';
import { ViewCommon } from '../service/viewcommon.service';
import { FocusDirective, FocusDirectiveModule } from './focus.directive';
import { LoggingService } from '../service/logging.service';

// noinspection TypeScriptUnresolvedFunction
require('../plugins/colResizable');

declare var $: any;

@Component({
    selector: 'rnl-datagrid',
    templateUrl: './datagrid.template.html',
})
export class DataGridComponent extends ViewDataGridElement implements OnInit, AfterViewInit {

    classesTh: string[];

    @HostListener('keydown', [ '$event' ])
    onKeyDown(e: KeyboardEvent) {
        let element: Element = e.srcElement;
        if (!this.rowSelect && this.list) {
            this.selectRow(this.list[ 0 ]);
        }

        if (this.list) {
            let idx: number = this.list.indexOf(this.rowSelect);

            // key down
            if (e.keyCode === 40) {
                if (idx < (this.list.length - 1)) {
                    idx++;
                    this.selectRow(this.list[ idx ]);
                }
            }

            // Key up
            if (e.keyCode === 38) {
                if (idx > 0) {
                    idx--;
                    this.selectRow(this.list[ idx ]);
                }
            }
        }
    }

    constructor(el: ElementRef, viewCommon: ViewCommon, private log: LoggingService) {
        super();
        this.id = el.nativeElement.id;
        this.classesTh = [];
        viewCommon.registerComponentElement(this);
    }

    ngOnInit() {

    }

    ngAfterViewInit() {
        $('table').colResizable();
    }

    selectRow(row: any) {
        this.rowSelect = row;
        this.list.forEach(r => {
            if (r === row) {
                r.__select = true;
            } else {
                r.__select = false;
            }
        });
    }

    onFocusEvent() {
        this.log.debug('Row focus', this.list);
        this.focused = false;
        if (this.list) this.selectRow(this.list[ 0 ]);
    }

    sort(i: number) {
        // if array is empty, create it.
        if (this.headers && this.classesTh.length === 0) {
            this.headers.forEach(value => this.classesTh.push(''));
        }
        // reset sort
        this.classesTh.forEach((v, idx) => {
            if (i !== idx) this.classesTh[ idx ] = '';
        });
        if (this.classesTh[ i ] === 'sort-ascent') {
            this.classesTh[ i ] = 'sort-descend';
        } else if (this.classesTh[ i ] === 'sort-descend') {
            this.classesTh[ i ] = 'sort-ascent';
        } else {
            this.classesTh[ i ] = 'sort-descend';
        }
    }

}

@NgModule({
    imports: [ FocusDirectiveModule, CommonModule ],
    exports: [ DataGridComponent ],
    declarations: [ DataGridComponent ]
})
export class DataGridModule {
}
