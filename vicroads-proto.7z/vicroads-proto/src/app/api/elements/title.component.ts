import { Component, Input } from '@angular/core';

@Component({
  selector: 'rnl-title',
  template: `
      <h2 class="rd_line rd_line_home"><span>{{title}}</span></h2>     
    `
})
export class TitleComponent {
  @Input()
  title: string;
}
