import {Component, ElementRef, Input, NgModule, EventEmitter, Output, forwardRef} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ViewCommon } from '../service/viewcommon.service';
import { LoggingService } from '../service/logging.service';
import { DomHandler } from '../service/domhandler.service';
import { Validation, ValidationType } from '../model/validation.model';
import { ViewValidation } from '../model/viewvalidation.element';
import { ValidationService } from './service/validation.service';
import {ViewElement} from "../model/view.element";

@Component({
    selector: 'rnl-text-box',
    template: `
    <div [attr.class]="classes" [ngClass]="{'has-error': hasError}">
      <label [attr.class]="labelClass" [attr.for]="inputId">
        <abbr *ngIf="inlineHelp !== ''" [attr.title]="inlineHelp">{{label}}</abbr>
        <span *ngIf="inlineHelp === ''">{{label}}</span>
        <span *ngIf="required">*</span>
       </label>
      <div [attr.class]="divInputClass">
        <input [attr.id]="inputId" 
               type="text" 
               [attr.class]="inputClass"
               [(ngModel)]="value" 
               [attr.title]="inlineHelp" 
               (keydown)="changeValue()"
               [disabled]="!enabled"
               />
         <span *ngFor="let item of validation.validations">
            <span *ngIf="!pristine && !item.valid" class="help-block">{{item.message}}</span>
         </span>
      </div>
    </div>
  `,
  providers: [{provide: ViewElement, useExisting: forwardRef(() => TextBoxComponent) }]
})
export class TextBoxComponent extends ViewValidation {
    labelClass: string;
    divInputClass: string;
    inputClass: string;
    @Input()
    generalCol: number;
    @Input()
    label: string;
    @Input()
    inlineHelp: string;
    @Input()
    placeholder: string;
    inputId: string;
    required: boolean;
    pristine: boolean;
    hasError: boolean;
    @Output()
    onError: EventEmitter<any> = new EventEmitter();
    oldValue: any;
    input: HTMLInputElement;

    /**
     * Text box component
     * @param el
     * @param viewCommon
     * @param log
     */
    constructor(private el: ElementRef,
                private viewCommon: ViewCommon,
                private log: LoggingService,
                private dom: DomHandler,
                private validationService: ValidationService) {
        super();
        this.id = el.nativeElement.id;
        this.viewCommon.registerComponentElement(this);
        this.classList.push('form-group');
        this.labelClass = 'control-label';
        if (!this.inlineHelp) this.inlineHelp = '';
        this.inputId = this.id + 'Input';
        this.inputClass = 'form-control';
        this.placeholder = '';
    }

    ngOnInit() {
        this.divInputClass = '';
        this.input = this.dom.findSingle(this.el.nativeElement, 'input');
        this.log.debug('Single', this.input);
        if (this.generalCol > 0) {
            this.labelClass += ' col-md-' + this.generalCol;
            this.divInputClass += ' col-md-' + this.generalCol;
        }
    }

    ngAfterViewInit() {

    }

    /**
     * On control value change or key
     * down check the validity of the value.
     */
    changeValue() {
        let value: string = this.input.value;
        setTimeout(() => {
            if (this.value !== this.oldValue) {
                this.validationService.validate(this);
                this.onError.emit(this.hasError);
            }
        }, 0);
        this.oldValue = this.value;
        this.log.debug('Validation', this.validation, String(this.value));
    }

}

@NgModule({
    declarations: [ TextBoxComponent ],
    exports: [ TextBoxComponent ],
    imports: [ CommonModule, FormsModule ]
})
export class TextBoxModule {
}
