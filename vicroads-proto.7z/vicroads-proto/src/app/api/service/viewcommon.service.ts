import { Injectable } from '@angular/core';
import { ViewModel } from '../model/view.model';
import { EventsCommon } from './eventcommon.service';
import { ViewElement } from '../model/view.element';
import { LoggingService } from './logging.service';
import { FormGroup } from '@angular/forms';
import { ValidationItem } from '../model/validation.model';
import { ViewValidation } from '../model/viewvalidation.element';
import { ValidationService } from '../elements/service/validation.service';

/**
 * View utility class.
 * It manage the view instance, its component and validations.
 */
@Injectable()
export class ViewCommon {

    private static _currentView: ViewModel;
    private static _errors: Set<ValidationItem> = new Set<ValidationItem>();
    private validationService: ValidationService;

    constructor(private eventsCommon: EventsCommon,
                private log: LoggingService) {
        // ,
        //           private validationService:ValidationService) {
        this.log.debug('Building services.... ViewCommon');
    }

    /**
     * Returns the current view.
     * @returns {ViewModel}
     */
    public getCurrentView(): ViewModel {
        return ViewCommon._currentView;
    }

    /**
     * Add validation to the current view.
     * @param value
     */
    public addValidationError(value: ValidationItem) {
        if (!ViewCommon._errors.has(value)) {
            ViewCommon._errors.add(value);
        }
    }

    /**
     * Check if a ValidationItem registered with this view contains an error.
     * If there is an error the flag 'valid' is set to false.
     * @returns {boolean}
     */
    public checkError(): boolean {
        ViewCommon._currentView.valid = true;
        ViewCommon._errors.forEach(v => {
            if (!v.valid) {
                ViewCommon._currentView.valid = false;
            }
        });
        return true;
    }

    /**
     * Register a View component, reset the validation errors
     * and broadcast an event to set view id.
     * @param value
     */
    public registerComponent(value: ViewModel): void {
        this.log.debug('Register Component View', value.id);
        ViewCommon._currentView = value;
        ViewCommon._errors = new Set<ValidationItem>();
        this.eventsCommon.broadcast(EventsCommon.UPDATE_VIEW_ID, value.id);
    }

    /**
     * Register a component element.
     * @param value
     */
    public registerComponentElement(value: ViewElement): void {
        this.log.debug('Register Component element', value.id);
        this.getCurrentView()[ value.id ] = value;
    }
}
