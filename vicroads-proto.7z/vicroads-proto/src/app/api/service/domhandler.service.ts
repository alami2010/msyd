import { Injectable } from '@angular/core';

@Injectable()
export class DomHandler {

    constructor() {
       console.log('BUILDING DOM HANDLER');
    }

    public addClass(element: any, className: string): void {
        if (element.classList) {
            element.classList.add(className);
        } else {
            element.className += ' ' + className;
        }
    }

    public addMultipleClasses(element: any, className: string): void {
        if (element.classList) {
            let styles: string[] = className.split(' ');
            for (let i = 0; i < styles.length; i++) {
                element.classList.add(styles[ i ]);
            }

        } else {
            let styles: string[] = className.split(' ');
            for (let i = 0; i < styles.length; i++) {
                element.className += ' ' + styles[ i ];
            }
        }
    }

    public removeClass(element: any, className: string): void {
        if (element.classList) {
            element.classList.remove(className);
        } else {
            element.className = element.className.replace(
                new RegExp('(^|\\b)'
                    + className.split(' ').join('|') + '(\\b|$)', 'gi'), ' ');
        }
    }

    public hasClass(element: any, className: string): boolean {
        if (element.classList) {
            return element.classList.contains(className);
        } else {
            return new RegExp('(^| )' + className + '( |$)', 'gi').test(element.className);
        }
    }

    public siblings(element: any): any {
        return Array.prototype.filter.call(element.parentNode.children, function (child) {
            return child !== element;
        });
    }

    public find(element: any, selector: string): any[] {
        return element.querySelectorAll(selector);
    }

    public findSingle(element: any, selector: string): any {
        return element.querySelector(selector);
    }

    /**
     * Used to find an element index, in list composed as follow:
     * ul
     *  li
     *    a < being the element passed.
     * @param element
     * @returns {number}
     */
    public index(element: any): number {
        let children: NodeList = element.parentNode.parentNode.childNodes;
        let num = 0;
        for (let i = 0; i < children.length; i++) {
            if (children[ i ] === element.parentNode) return num;
            if (children[ i ].nodeType === 1) num++; // 1 = HTML node, avoid comments and text.
        }
        return -1;
    }

    public relPosition(element: any, target: any): void {
        console.log('Target', target.offsetHeight, target.offsetLeft);
        element.style.top = target.offsetTop + target.offsetHeight + 'px';
        element.style.left = target.offsetLeft + 'px';
    }

    public relativePosition(element: any, target: HTMLElement): void {
        let elementOuterHeight = element.offsetParent ? element.offsetHeight
            : this.getHiddenElementOuterHeight(element);
        let targetHeight = target.offsetHeight;
        let targetOffset = target.getBoundingClientRect();
        let top;

        if ((targetOffset.top + targetHeight + elementOuterHeight) > window.innerHeight) {
            top = -1 * (elementOuterHeight);
        } else {
            top = targetHeight;
        }

        element.style.top = (top - targetOffset.height) + 'px';
        element.style.left = (targetOffset.width + 16) + 'px';
        console.log('Pos top' + element.style.top + ' pos left:' + element.style.left, target);
    }

    public absolutePosition(element: any, target: any): void {
        let elementOuterHeight = element.offsetParent ? element.offsetHeight
            : this.getHiddenElementOuterHeight(element);
        let targetOuterHeight = target.offsetHeight;
        let targetOffset = target.getBoundingClientRect();
        let windowScrollTop = this.getWindowScrollTop();
        let top;

        if (targetOffset.top + targetOuterHeight + elementOuterHeight > window.innerHeight) {
            top = targetOffset.top + windowScrollTop - elementOuterHeight;
        } else {
            top = targetOuterHeight + targetOffset.top + windowScrollTop;
        }

        element.style.top = top + 'px';
        element.style.left = targetOffset.left + 'px';
        console.log('Pos top', element.style.top, 'pos left:', element.style.left);
    }

    public getHiddenElementOuterHeight(element: any): number {
        element.style.visibility = 'hidden';
        element.style.display = 'block';
        let elementHeight = element.offsetHeight;
        element.style.display = 'none';
        element.style.visibility = 'visible';

        return elementHeight;
    }

    public scrollInView(container, item) {
        let borderTopValue: string = getComputedStyle(container).getPropertyValue('borderTopWidth');
        let borderTop: number = borderTopValue ? parseFloat(borderTopValue) : 0;
        let paddingTopValue: string = getComputedStyle(container).getPropertyValue('paddingTop');
        let paddingTop: number = paddingTopValue ? parseFloat(paddingTopValue) : 0;
        let containerRect = container.getBoundingClientRect();
        let itemRect = item.getBoundingClientRect();
        let offset = (itemRect.top + document.body.scrollTop)
            - (containerRect.top + document.body.scrollTop) - borderTop - paddingTop;
        let scroll = container.scrollTop;
        let elementHeight = container.clientHeight;
        let itemHeight = this.getOuterHeight(item);

        if (offset < 0) {
            container.scrollTop = scroll + offset;
        } else if ((offset + itemHeight) > elementHeight) {
            container.scrollTop = scroll + offset - elementHeight + itemHeight;
        }
    }

    public getOuterHeight(element): number {
        let height: number = element.offsetHeight;
        let style: any = getComputedStyle(element);

        height += parseInt(style.marginTop, 10) + parseInt(style.marginBottom, 10);
        return height;
    }

    public fadeIn(element, duration: number): void {
        element.style.opacity = 0;

        let last = +new Date();
        let tick = function () {
            element.style.opacity = +element.style.opacity
                + (new Date().getTime() - last) / duration;
            last = +new Date();

            if (+element.style.opacity < 1) {
                let a = (window.requestAnimationFrame && requestAnimationFrame(tick))
                    || setTimeout(tick, 16);
            }
        };

        tick();
    }

    public getWindowScrollTop(): number {
        let doc = document.documentElement;
        return (window.pageYOffset || doc.scrollTop) - (doc.clientTop || 0);
    }

    public matches(element, selector: string): boolean {
        let p = Element.prototype;
        let f = p[ 'matches' ] || p.webkitMatchesSelector
            || p[ 'mozMatchesSelector' ] || p.msMatchesSelector || function (s) {
                return [].indexOf.call(document.querySelectorAll(s), this) !== -1;
            };
        return f.call(element, selector);
    }

    /**
     * Get the further matching element up the DOM tree.
     * @param  {Element} elem     Starting element
     * @param  {String}  selector Selector to match against (class, ID, data attribute, or tag)
     * @return {Element}  Returns null if not match found
     */
    public getFurthest(elem: any, selector: string) {

        // Variables
        let elements: any[] = [];
        let firstChar = selector.charAt(0);
        let supports = 'classList' in document.documentElement;
        let attribute, value;

        // If selector is a data attribute, split attribute from value
        if (firstChar === '[') {
            selector = selector.substr(1, selector.length - 2);
            attribute = selector.split('=');

            if (attribute.length > 1) {
                value = true;
                attribute[ 1 ] = attribute[ 1 ].replace(/"/g, '').replace(/'/g, '');
            }
        }

        // Get closest match
        for (; elem && elem !== document && elem.nodeType === 1; elem = elem.parentNode) {

            // If selector is a class
            if (firstChar === '.') {
                if (supports) {
                    if (elem.classList.contains(selector.substr(1))) {
                        elements.push(elem);
                    }
                } else {
                    if (new RegExp('(^|\\s)' + selector.substr(1) + '(\\s|$)')
                            .test(elem.className)) {
                        elements.push(elem);
                    }
                }
            }

            // If selector is an ID
            if (firstChar === '#') {
                if (elem.id === selector.substr(1)) {
                    elements.push(elem);
                }
            }

            // If selector is a data attribute
            if (firstChar === '[') {
                if (elem.hasAttribute(attribute[ 0 ])) {
                    if (value) {
                        if (elem.getAttribute(attribute[ 0 ]) === attribute[ 1 ]) {
                            elements.push(elem);
                        }
                    } else {
                        elements.push(elem);
                    }
                }
            }
            // If selector is a tag
            if (elem.tagName.toLowerCase() === selector) {
                elements.push(elem);
            }
        }
        return elements[ elements.length - 1 ];

    }

    /**
     * Get the closest matching element up the DOM tree.
     * @param  {Element} elem     Starting element
     * @param  {String}  selector Selector to match against (class, ID, data attribute, or tag)
     * @return {Element}  Returns null if not match found
     */
    public getClosest(elem: any, selector: string) {

        // Variables
        let firstChar = selector.charAt(0);
        let supports = 'classList' in document.documentElement;
        let attribute: string[];
        let value: boolean;

        // If selector is a data attribute, split attribute from value
        if (firstChar === '[') {
            selector = selector.substr(1, selector.length - 2);
            attribute = selector.split('=');

            if (attribute.length > 1) {
                value = true;
                attribute[ 1 ] = attribute[ 1 ].replace(/"/g, '').replace(/'/g, '');
            }
        }

        // Get closest match
        for (; elem && elem !== document && elem.nodeType === 1; elem = elem.parentNode) {

            // If selector is a class
            if (firstChar === '.') {
                if (supports) {
                    if (elem.classList.contains(selector.substr(1))) {
                        return elem;
                    }
                } else {
                    if (new RegExp('(^|\\s)' + selector.substr(1) + '(\\s|$)')
                            .test(elem.className)) {
                        return elem;
                    }
                }
            }

            // If selector is an ID
            if (firstChar === '#') {
                if (elem.id === selector.substr(1)) {
                    return elem;
                }
            }

            // If selector is a data attribute
            if (firstChar === '[') {
                if (elem.hasAttribute(attribute[ 0 ])) {
                    if (value) {
                        if (elem.getAttribute(attribute[ 0 ]) === attribute[ 1 ]) {
                            return elem;
                        }
                    } else {
                        return elem;
                    }
                }
            }
            // If selector is a tag
            if (elem.tagName.toLowerCase() === selector) {
                return elem;
            }
        }
        return null;
    }
}
