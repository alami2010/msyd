import { DataStoreService } from './datastore.service';
import { ViewCommon } from './viewcommon.service';
import { PluginService } from '../plugins/plugin.service';

export const COMMON_SERVICES_PROVIDERS: any[] = [
    DataStoreService, ViewCommon, PluginService
];
