import { Injectable } from '@angular/core';

@Injectable()
export class LoggingService {

    debug: any;
    info: any;
    error: any;

    /**
     * Rebinds console[debug/info/error] to this service functions.
     */
    constructor() {

        this.info = Function.prototype.bind.call(console.log, console);
        this.debug = Function.prototype.bind.call(console.debug, console);
        this.error = Function.prototype.bind.call(console.error, console);

    }
}
