import { Injectable } from '@angular/core';
import { ClientModel } from '../model/domain/client.model';
import { BranchModel } from '../model/domain/branch.model';
import { UserModel } from '../model/security/user.model';

@Injectable()
export class DataStoreService {
    private static _client: ClientModel;
    private static _branch: BranchModel;
    private static _user: UserModel;

    constructor() {
        DataStoreService._client = new ClientModel();
        DataStoreService._branch = new BranchModel(null, null);
        if (!window.sessionStorage['user']) window.sessionStorage['user'] =
            JSON.stringify(new UserModel(null, null, null));
    }

    public get client(): ClientModel {
        return DataStoreService._client;
    }

    public set client(value: ClientModel) {
        DataStoreService._client = value;
    }

    public get branch(): BranchModel {
        return DataStoreService._branch;
    }

    public set branch(value: BranchModel) {
        DataStoreService._branch = value;
    }

    public get user(): UserModel {
        return JSON.parse(window.sessionStorage['user']);
    }

    public set user(value: UserModel) {
        window.sessionStorage['user'] = JSON.stringify(value);
    }
}
