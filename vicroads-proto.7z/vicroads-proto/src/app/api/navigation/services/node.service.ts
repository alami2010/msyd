import { Injectable } from "@angular/core";
import { NodeType, NodeModel } from "../model/node.model";

/**
 * Service to manage Tree View nodes
 */
@Injectable()
export class NodeService {

    private nodeFound: NodeModel = null;

    /**
     * Add a node to the node Tree
     * ```
     * this.nodeService.addNode('Identity', NodeType.LEAF, '.l0005_identity', nSearch);
     * this.nodeService.addNode('Person', NodeType.LEAF, '.l0006_person', nSearch);
     * ```
     * @param name the _name of the node
     * @param type type of nodes LEAF, ROOT, or Tree NODE
     * @param link state _name it should a relative state
     * @param parent the parent node.
     * @returns {NodeModel} the first level of nodes.
     */
    public addNode(name: string,
                   type: NodeType,
                   link: string,
                   parent: NodeModel): NodeModel {
        return this.addNodeParameter(name, type, link, parent, null);
    }

    /**
     * Add Node with parameters.
     * @param name
     * @param type
     * @param link node link
     * @param parent parent node
     * @param params node state parameters
     * @param onSelect call back function (value:NodeModel) => {}
     * @returns {NodeModel}
     */
    public addNodeParameter(name: string,
                            type: NodeType,
                            link: string,
                            parent: NodeModel,
                            params: any,
                            onSelect?: any): NodeModel {
        let newNode: NodeModel = new NodeModel();
        if (!name) {
            throw 'You cannot add a TreeView with a null _name.';
        }
        newNode.id = (parent.name ? parent.id : '_NTV_R_')
            + name.toUpperCase()[ 0 ] + String(parent.children ? parent.children.length : 0);
        newNode.name = name;
        newNode.type = type;
        if (type === NodeType.NODE) {
            newNode.icon = 'fa fa-chevron-circle-right';
            newNode.iconExpanded = 'fa fa-chevron-circle-down';
        } else if (type === NodeType.FOLDER
            || type === NodeType.GROUP_ONE
            || type === NodeType.GROUP_TWO
            || type === NodeType.GROUP_FOUR) {
            newNode.icon = 'fa fa-folder';
            newNode.iconExpanded = 'fa fa-folder-open';
        } else if (type === NodeType.LEAF
            || type === NodeType.GROUP_THREE) {
            newNode.icon = 'fa fa-file-o';
            newNode.iconExpanded = null;
        }
        if (link) {
            newNode.link = link;
        }

        if (params) {
            newNode.params = params;
        }

        if (onSelect) {
            newNode.onSelect = onSelect;
        }
        if (!parent.children) parent.children = [];
        parent.children.push(newNode);
        newNode.parent = parent;


        return newNode;
    }

    /**
     * Display the current state in the page is reloaded.
     * Or the page is accessed directly typed in browser URL.
     * This will expand the node path down to the selected element.
     * ```
     * this.clientService.selectStateInView(this.navigationNodes, this.stateService.$current);
     * ```
     * @param node the root node
     * @param state URL path (after the '#').
     */
    public selectStateInView(node: NodeModel, state: string) {
        console.log('Tree selection state in view...');
        if (state) {
            let composedState: string[] = state.split('/');
            if (composedState.length > 0) {
                for (let i: number = composedState.length - 1; i > 0; i--) {
                    let stateName = composedState[ i ];
                    this.findNodeByProperty(node, 'link', stateName);
                    if (this.nodeFound) {
                        // this.nodeFound._active = true;
                        this.activateNode(this.nodeFound);
                        // let parent = this.nodeFound;
                        // while (parent !== null && parent.parent !== null) parent = parent.parent;
                        // console.log('Tree collapse all...', parent.children);
                        // this.collapseAllNodes(parent.children);
                        // let parent: NodeModel = this.nodeFound;
                        // while (parent) {
                        //     parent.expanded = true;
                        //     parent = parent.parent;
                        // }
                        this.nodeFound = null;
                        break;
                    }
                }
            }
        }
    }

    /**
     * Select a tree view node from its id.
     * @param node the tree view node data.
     * @param id of the node.
     */
    public selectIdInView(node: NodeModel, id: string) {
        if (id) {
            this.nodeFound = null;
            this.findNodeByProperty(node, 'id', id);
            if (this.nodeFound) {
                let parent: NodeModel = this.nodeFound;
                parent.focus = true;
                while (parent) {
                    parent.expanded = true;
                    parent = parent.parent;
                }
                this.nodeFound = null;
            }
        }
    }

    /**
     * Traverse the node tree and find a node where node.link === link.
     * @param node
     * @param propName
     * @param value
     * @returns {NodeModel}
     */
    public findNodeByProperty(node: NodeModel, propName: string, value: string): NodeModel {
        if (node[ propName ] === value) {
            this.nodeFound = node;
        }
        if (node.children) {
            node.children.forEach((n: NodeModel) => {
                return this.findNodeByProperty(n, propName, value);
            });
        }
        return this.nodeFound;
    }

    /**
     * Disable all node but the one contains in ids
     * @param ids array containing node's id.
     * @param nodes tree view node data.
     */
    public disableAllNodeBut(ids: string[], nodes: NodeModel[]) {
        this.traverseTreeAndSetProperty(ids, nodes, 'enabled', true, false);
    }

    /**
     * Enables all nodes
     * @param nodes tree view node data.
     */
    public enableAllNodes(nodes: NodeModel[]) {
        this.traverseTreeAndSetProperty([], nodes, 'enabled', true, true);
    }

    /**
     * Expands all nodes.
     * @param nodes tree view node data.
     */
    public expandAllNodes(nodes: NodeModel[]) {
        this.traverseTreeAndSetProperty([], nodes, 'expanded', true, true);
    }

    /**
     * Expands all nodes.
     * @param nodes tree view node data.
     */
    public collapseAllNodes(nodes: NodeModel[]) {
        this.traverseTreeAndSetProperty([], nodes, 'expanded', false, false);
    }

    public expandParents(node: NodeModel) {
        let parent = node;
        while (parent !== null && parent.parent !== null) {
            parent.expanded = true;
            parent = parent.parent;
        }
    }

    /**
     * Set the current node active and deactivate all other.
     * @param node
     */
    public activateNode(node: NodeModel) {
        if (node && node.link && node.link !== '') {
            let parent: NodeModel = node.parent;
            while (parent && parent.parent) {
                parent = parent.parent;
            }
            this.collapseAllNodes(parent.children);
            this.expandParents(node);
            this.traverseTreeAndSetProperty([], parent.children, '_active', false, false);
            node.parent.expanded = true;
            node._active = true;
        }
    }

    /**
     * Set generic property in the tree view.
     * @param ids array of node's id. If empty,
     * only default property will be set.
     * @param nodes tree view node data.
     * @param propName property _name to set
     * @param value property value.
     * @param defaultValue default value
     * to set for nodes not in the ids array.
     */
    public traverseTreeAndSetProperty(ids: string[],
                                      nodes: NodeModel[],
                                      propName: string,
                                      value: any,
                                      defaultValue?: any) {
        if (nodes) {
            nodes.forEach(v => {
                let idx: number = ids.indexOf(v.id);
                if (idx >= 0) {
                    v[ propName ] = value;
                } else if (typeof(defaultValue) !== 'undefined') {
                    v[ propName ] = defaultValue;
                }
                this.traverseTreeAndSetProperty(ids, v.children, propName, value, defaultValue);
            });
        }
    }
}
