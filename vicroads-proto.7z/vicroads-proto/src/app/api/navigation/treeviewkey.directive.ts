import { Directive, Input, HostListener, ElementRef, NgModule } from '@angular/core';
import { NodeModel } from './model/node.model';
import { NodeService } from './services/node.service';
import { LoggingService } from '../service/logging.service';
import { DomHandler } from '../service/domhandler.service';

declare var $: any;

@Directive({
    selector: '[treeViewKey]',
    providers: [ DomHandler ]
})
export class TreeViewKeyDirective {
    private static prevId = '';
    @Input()
    treeViewKey: NodeModel;
    private timer: number = 300;
    private doTrigger: boolean = true;
    private rootComponent: Element;

    ngOnInit() {
        if (this.treeViewKey && this.treeViewKey.onSelect && this.treeViewKey._active) {
            // Can happen on focus...
        }
        this.rootComponent = this.domHandler.getFurthest(this.el.nativeElement, 'navigation-tree');
    }

    @HostListener('focus', [ '$event' ]) onFocusEvent(e: Event) {
        this.nodeService.activateNode(this.treeViewKey);
        if (this.treeViewKey.onSelect && this.doTrigger) {
            // Call back to display other actions.
            this.treeViewKey.onSelect.call(null, this.treeViewKey);
        }
    }

    @HostListener('click', [ '$event' ]) onClick(e: Event) {
        this.onFocusEvent(e);
    }

    @HostListener('keydown', [ '$event' ]) onKeyDown(e: KeyboardEvent) {
        let el: Element = e.srcElement;
        // 40 key down
        if (e.keyCode === 40) {
            let jq: any = $(this.el.nativeElement);
            let element: NodeListOf<Element> = jq.parent().parent().parent().find('span');
            if (element) {
                let stop: boolean = false;
                let next: any = null;
                for (let i: number = 0; i < element.length; i++) {
                    let current: Element = element[ i ];
                    if (stop && current.id && current.id.startsWith('_NTV_R_')
                        && current.id !== this.el.nativeElement.id) {
                        next = current;
                        break;
                    }
                    if (current.id === this.el.nativeElement.id) {
                        stop = true;
                    }
                }

                if (!next) {
                    element = this.rootComponent.querySelectorAll('span');
                    stop = false;
                    for (let i: number = 0; i < element.length; i++) {
                        let current: Element = element[ i ];
                        if (stop && current.id && current.id.startsWith('_NTV_R_')
                            && current.id !== this.el.nativeElement.id) {
                            next = current;
                            break;
                        }
                        if (current.id === this.el.nativeElement.id) {
                            stop = true;
                        }
                    }
                }

                if (next) {
                    next.focus();
                    TreeViewKeyDirective.prevId = next.id;
                    if (next.querySelector('a')) {
                        setTimeout(() => {
                            if (TreeViewKeyDirective.prevId === next.id)
                                next.querySelector('a').click();
                        }, this.timer);
                    }
                }
                return;
            }
        }
        // 39 key right
        if (e.keyCode === 39) {
            this.doTrigger = false;
            this.treeViewKey.expanded = true;
        }
        // 38 key up
        if (e.keyCode === 38) {
            let jq: any = $(this.el.nativeElement);
            let element: any[] = jq.parent().parent().parent().find('span');
            if (element) {
                let prev: any = null;
                for (let i: number = 0; i < element.length; i++) {
                    let current: Element = element[ i ];
                    if (current.id && current.id.startsWith('_NTV_R_')
                        && current.id !== this.el.nativeElement.id) {
                        prev = current;
                    }
                    if (current.id === this.el.nativeElement.id) {
                        break;
                    }
                }

                if (!prev) {
                    element = jq.parent()
                        .parent()
                        .parent()
                        .parent()
                        .parent()
                        .parent()
                        .parent()
                        .parent().find('span');
                    for (let i: number = 0; i < element.length; i++) {
                        let current: Element = element[ i ];
                        if (current.id && current.id.startsWith('_NTV_R_')
                            && current.id !== this.el.nativeElement.id) {
                            prev = current;
                        }
                        if (current.id === this.el.nativeElement.id) {
                            break;
                        }
                    }
                }

                if (prev) {
                    prev.focus();
                    TreeViewKeyDirective.prevId = prev.id;
                    if (prev.querySelector('a')) {
                        setTimeout(() => {
                            if (TreeViewKeyDirective.prevId === prev.id)
                                prev.querySelector('a').click();
                        }, this.timer);
                    }
                }
                this.doTrigger = true;
                return;
            }
        }
        // 37 key left
        if (e.keyCode === 37) {
            this.treeViewKey.expanded = false;
        }
        this.doTrigger = true;
        console.log('Key down event', e.keyCode);
    }

    constructor(private el: ElementRef,
                private nodeService: NodeService,
                private log: LoggingService,
                private domHandler: DomHandler) {
    }
}

@NgModule({
    declarations: [ TreeViewKeyDirective ],
    exports: [ TreeViewKeyDirective ]
})
export class TreeViewKeyModule {
}
