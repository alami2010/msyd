export class NodeModel {
    id: string;
    name: string;
    type: NodeType;
    icon: string;
    iconExpanded: string;
    link: string;
    expanded: boolean;
    children: NodeModel[];
    parent: NodeModel;
    tabIndex: number;
    visible: boolean;
    classList: string[];
    focus: boolean;
    params: any;
    _active: boolean;
    rootPath: string[];

    private _enabled: boolean;

    onSelect: Function = (value: any) => {
    };

    public get enabled(): boolean {
        return this._enabled;
    }

    public set enabled(value: boolean) {
        let idx: number = this.classList.indexOf('node-disabled');
        if (value) {
            if (idx > 0) {
                this.classList.splice(idx);
            }
        } else if (idx === -1) {
            this.classList.push('node-disabled');
        }
        this._enabled = value;
    }

    public get classes(): string {
        return this.classList.join(' ');
    }

    constructor() {
        this.id = '';
        this.classList = [];
        this.classList.push('node');
        this.name = '';
        this.type = NodeType.NONE;
        this.icon = null;
        this.iconExpanded = null;
        this.link = null;
        this.expanded = false;
        this.children = null;
        this.parent = null;
        this.enabled = true;
        this.visible = true;
        this.tabIndex = 0;
        this.focus = false;
        this.params = null;
        this._active = false;
    }
}

export enum NodeType {
    NODE = 1,
    LEAF = 2,
    ROOT = 4,
    FOLDER = 5,
    GROUP_ONE = 6,
    GROUP_TWO = 7,
    GROUP_THREE = 8,
    GROUP_FOUR = 9,
    NONE = 0
}
