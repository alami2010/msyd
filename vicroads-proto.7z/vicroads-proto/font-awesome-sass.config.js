/**
 * Created by j.neveux on 29/04/2016.
 */
module.exports = {
  fontAwesomeCustomizations: "./_font-awesome.config.scss",
  styles: {
    "mixins": true,

    "core": true,
    "icons": true,

    "larger":  true,
    "path": true,
  }
};
