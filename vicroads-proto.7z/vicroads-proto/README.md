![VicRoads Logo](http://srv-161106.netfective.com/jneveux/vicroads-proto/raw/f32847397f5a36eda83e57681b62252280f9bec0/.readme_assets/vicroadsLogo.png)
# VicRoads RnL 
prototype version 1.0


## Project goals
This prototype is targeted for architect, UI designer and UI developer.
You need to be able to understand the following general concepts described in architecture.
## Architecture
* Angular 2.x
* Webpack 2.x
* ECMAScript 6 (ES2015)
* TypeScript 2.x
* jQuery 2.x
* HTML 5
* CSS 3
* Bootstrap 3.x

<img src="http://srv-161106.netfective.com/jneveux/vicroads-proto/raw/f32847397f5a36eda83e57681b62252280f9bec0/.readme_assets/parkedcarsandtraffic1high.jpg"/>

