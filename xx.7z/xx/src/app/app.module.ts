import {NgModule, ApplicationRef, Provider} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {FormsModule} from '@angular/forms';
import {
  HttpModule,
  XHRBackend,
  RequestOptions,
  Http,
  XSRFStrategy,
  CookieXSRFStrategy
} from '@angular/http';
import {HashLocationStrategy, LocationStrategy} from '@angular/common';
import {RouterModule, Router, ActivatedRoute} from '@angular/router';
import {removeNgStyles, createNewHosts, createInputTransfer} from '@angularclass/hmr';

/*
 * Platform and Environment providers/directives/pipes
 */
import {ENV_PROVIDERS} from './environment';
import {ROUTES} from './app.routes';
// App is our top level component
import {App} from './app.component';
import {APP_RESOLVER_PROVIDERS} from './app.resolver';
import {AppState, InteralStateType} from './app.service';
import {L0010MessagesComponent} from './message/l0010_message.component';
import {MessageService} from './message/services/message.service';
import {MessageResolver} from './message/services/message.resolver.service';
import {NavigationTreeViewModule} from './api/navigation/navigationtreeview.component';
import {FocusDirectiveModule} from './api/elements/focus.directive';
import {ToasterModule} from './api/toaster/toaster.module';
import {PluginService} from './api/plugins/plugin.service';
import {EventsCommon} from './api/service/eventcommon.service';
import {ViewCommon} from './api/service/viewcommon.service';
import {LoggingService} from './api/service/logging.service';
import {ActionButtonModule} from './api/elements/actionbutton.component';
import {DataStoreService} from './api/service/datastore.service';
import {BranchResolver} from './licences/services/branch.resolver.service';
import {BranchService} from './licences/services/branch.service';
import {L0004LicencesComponent} from './licences/l0004_licences.component';
import {LicencesResolver} from './licences/services/licences.resolver.service';
import {ClientFindService} from './licences/client/search/services/clientfind.service';
import {LoginService} from './login/services/login.service';
import {L0009LoginComponent} from './login/l0009_login.component';
import {ToasterService} from './api/toaster/toaster.service';
import {AuthHttpService} from './api/service/authhttp.service';
import {AuthGard} from './api/service/authgard.service';
import {MainModule} from "./design/main.component";
import {TestMaskModule} from "./design/test_mask.component";
import {DomHandler} from "./api/service/domhandler.service";
import {ValidationService} from "./api/elements/service/validation.service";
import {DatepickerModule} from "ng2-bootstrap";
import {RnlDatePickerModule} from "./api/elements/datepicker.component";
import {MyRnlDatePickerModule} from "./api/elements/mydatepicker.component";

// Application wide providers
const APP_PROVIDERS = [
  ...APP_RESOLVER_PROVIDERS,
  AppState,
  MessageService,
  MessageResolver,
  PluginService,
  EventsCommon,
  ViewCommon,
  LoggingService,
  DataStoreService,
  BranchResolver,
  BranchService,
  LicencesResolver,
  ClientFindService,
  LoginService,
  ToasterService,
  {provide: XSRFStrategy, useValue: new CookieXSRFStrategy('XSRF-TOKEN', 'X-XSRF-TOKEN')},
  {
    provide: Http,
    useFactory: (backend: XHRBackend,
                 defaultOptions: RequestOptions,
                 eventsCommon: EventsCommon,
                 router: Router,
                 route: ActivatedRoute,
                 dataStore: DataStoreService) =>
      new AuthHttpService(backend, defaultOptions, eventsCommon, router, route, dataStore),
    deps: [XHRBackend, RequestOptions, EventsCommon, Router, ActivatedRoute, DataStoreService]
  },
  {provide: LocationStrategy, useClass: HashLocationStrategy},
  AuthGard
];

type StoreType = {
  state: InteralStateType,
  restoreInputValues: () => void,
  disposeOldHosts: () => void
};

/**
 * `AppModule` is the main entry point into Angular2's bootstraping process
 */
@NgModule({
  bootstrap: [App],
  declarations: [
    App,
    L0010MessagesComponent,
    L0004LicencesComponent,
    L0009LoginComponent
  ],
  imports: [ // import Angular's modules
    BrowserModule,
    FormsModule,
    HttpModule,
    MainModule,
    TestMaskModule,
    RouterModule.forRoot(ROUTES, {useHash: true}),
    ToasterModule,
    ActionButtonModule,
    FocusDirectiveModule,
    NavigationTreeViewModule,
    DatepickerModule,
    RnlDatePickerModule,
    MyRnlDatePickerModule
  ],
  providers: [ // expose our Services and Providers into Angular's dependency injection
    ENV_PROVIDERS,
    APP_PROVIDERS,
    DomHandler,
    ValidationService
  ]
})
export class AppModule {
  constructor(public appRef: ApplicationRef, public appState: AppState) {
  }

  hmrOnInit(store: StoreType) {
    if (!store || !store.state) return;
    console.log('HMR store', JSON.stringify(store, null, 2));
    // set state
    this.appState._state = store.state;
    // set input values
    if ('restoreInputValues' in store) {
      let restoreInputValues = store.restoreInputValues;
      setTimeout(restoreInputValues);
    }

    this.appRef.tick();
    delete store.state;
    delete store.restoreInputValues;
  }

  hmrOnDestroy(store: StoreType) {
    const cmpLocation = this.appRef.components.map(cmp => cmp.location.nativeElement);
    // save state
    const state = this.appState._state;
    store.state = state;
    // recreate root elements
    store.disposeOldHosts = createNewHosts(cmpLocation);
    // save input values
    store.restoreInputValues = createInputTransfer();
    // remove styles
    removeNgStyles();
  }

  hmrAfterDestroy(store: StoreType) {
    // display new elements
    store.disposeOldHosts();
    delete store.disposeOldHosts;
  }

}

