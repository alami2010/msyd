import { Injectable } from '@angular/core';

// noinspection TypeScriptUnresolvedFunction
require('./icheck');
// noinspection TypeScriptUnresolvedFunction
require('./jClock');
// noinspection TypeScriptUnresolvedFunction
require('./slimScroll');


declare let $: any;

/**
 * General jQuery operations.
 */
@Injectable()
export class PluginService {

    /**
     * Displays the current date and time.
     */
    jClock() {
        let jclockOpt = {format: '%B %d, %Y - %H:%M'};
        $('#rd_jclock').jclock(jclockOpt);
    }

    /**
     * Applies default scrolling behavior on Navigation Tree View.
     */
    applyNavigationTreeViewScroll() {
        let rdSsmargin = 165;
        let rdSsminspace = 400;
        let rdHeightPx = ($(window).height() - rdSsmargin);
        if (rdHeightPx < rdSsminspace) rdHeightPx = rdSsminspace;
        $('.rd_slimscroll').slimScroll({
            height: rdHeightPx,
            railVisible: false,
            alwaysVisible: false,
            color: '#80b816'
        });
        $(window).resize(function () {
            let rdHeight = $(window).height() - rdSsmargin;
            if (rdHeight > rdSsminspace) {
                $('.rd_slimscroll').height(rdHeight);
                $('.slimScrollDiv').height(rdHeight);
            }
        });
    }

    /**
     * Enable hide/visible behavior for the Navigation Tree View menu button.
     */
    collaspeTreeViewMenu() {
        $('#rd_fxcol00').click(function (e) {
            e.preventDefault();
            if ($('#rd_col00').length) {
                if ($('#rd_col00').hasClass('hidden')) {
                    $('#rd_col00').removeClass('hidden');
                    $('#rd_fxcol00').toggleClass('active');
                    $('#rd_fxcol00 i').removeClass('fa-square').addClass('fa-check-square');
                    $('#rd_col01').removeClass('col-sm-12')
                        .addClass('col-sm-8 col-sm-push-4 col-md-9' +
                            ' col-md-push-3 col-lg-10 col-lg-push-2');
                } else {
                    $('#rd_col00').addClass('hidden');
                    $('#rd_fxcol00').toggleClass('active');
                    $('#rd_fxcol00 i').removeClass('fa-check-square').addClass('fa-square');
                    $('#rd_col01').removeClass('col-sm-8 col-sm-push-4' +
                        ' col-md-9 col-md-push-3 col-lg-10 col-lg-push-2').addClass('col-sm-12');
                }
            }
        });
    }

    collaspeTreeViewMenuInView() {
        /* collapse logic II */
        if ($('#rd_fxcol00').hasClass('active')) {
            $('#rd_col00').removeClass('hidden');
            $('#rd_col01').removeClass('col-sm-12')
                .addClass('col-sm-8 col-sm-push-4 col-md-9 col-md-push-3 col-lg-10 col-lg-push-2');
        } else {
            $('#rd_col00').addClass('hidden');
            $('#rd_col01').removeClass('col-sm-8 col-sm-push-4 col-md-9' +
                ' col-md-push-3 col-lg-10 col-lg-push-2')
                .addClass('col-sm-12');
        }
    }

    /* icheck */
    icheckInit() {
        $('input').iCheck({
            checkboxClass: 'icheckbox_square-green', radioClass: 'iradio_square-green'
        });
    }
}

