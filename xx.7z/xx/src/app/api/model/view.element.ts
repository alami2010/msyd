import {Output, EventEmitter} from "@angular/core";
export class ViewElement {

    id: string;
    visible: boolean;
    enabled: boolean;
    value: any;
    classList: string[];
    onError: EventEmitter<any>;

    get classes(): string {
        return this.classList.join(' ');
    }

    constructor() {
        this.visible = true;
        this.enabled = true;
        this.classList = [];
    }
}
