import { ViewFocusedElement } from './viewfocus.element';
import { KeyValueModel } from './keyvalue.model';

export class ViewListElement extends ViewFocusedElement {

    list: KeyValueModel[];
    size: number;

    constructor() {
        super();
        this.list = [];
        this.size = 0;
    }

}
