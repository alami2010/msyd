import { Validation } from './validation.model';

export interface ValidationInterface {
    validation: Validation;
    pristine: boolean;
    valid: boolean;
    hasError: boolean;
    value: any;
}
