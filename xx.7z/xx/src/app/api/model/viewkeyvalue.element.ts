import { ViewFocusedElement } from './viewfocus.element';
import { KeyValueModel } from './keyvalue.model';

export class ViewKeyValue extends ViewFocusedElement {
    keyValue: KeyValueModel;
}
