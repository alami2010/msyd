import {
    Component,
    ElementRef,
    EventEmitter,
    Input,
    NgModule,
    forwardRef,
    Output
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { ViewListElement } from '../model/viewlist.element';
import { ViewCommon } from '../service/viewcommon.service';
import { LoggingService } from '../service/logging.service';
import { KeyValueModel } from '../model/keyvalue.model';
import { NG_VALUE_ACCESSOR, ControlValueAccessor } from '@angular/forms';

export const RDL_VALUE_ACCESSOR: any = {
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => RnlRadioListComponent),
    multi: true
};

@Component({
    selector: 'rnl-radio-list',
    templateUrl: './radiolist.template.html',
    providers: [ RDL_VALUE_ACCESSOR ]
})
export class RnlRadioListComponent extends ViewListElement implements ControlValueAccessor {

    listId: string[];
    @Input()
    list: KeyValueModel[];
    @Output()
    radioSelect: EventEmitter<KeyValueModel> = new EventEmitter<KeyValueModel>(false);
    @Input()
    horizontal: boolean = false;
    @Input()
    value: any;

    onModelChange: Function = (value: any) => {
    };
    onModelTouched: Function = () => {
    };

    constructor(private el: ElementRef,
                private  viewCommon: ViewCommon,
                private log: LoggingService) {
        super();
        this.listId = [];
        if (!this.list) {
            this.list = [];
        }
        // if(!this.value) {
        //   this.value = {};
        // }
        this.id = this.el.nativeElement.id;
        this.viewCommon.registerComponentElement(this);
    }

    ngOnInit() {
        this.list.forEach((v: KeyValueModel, i: number) => {
            this.listId.push(this.id + String(v.key));
        });

        if (this.horizontal) {

        }
    }

    radioChange(e: any, item: KeyValueModel) {
        this.radioSelect.emit(item);
        this.onModelChange(item.key);
    }

    writeValue(value: any): void {
        if (value) this.value = value;
        this.log.debug('Bound value', value);
    }

    registerOnChange(fn: Function): void {
        this.onModelChange = fn;
    }

    registerOnTouched(fn: Function): void {
        this.onModelTouched = fn;
    }
}

@NgModule({
    imports: [ CommonModule ],
    exports: [ RnlRadioListComponent ],
    declarations: [ RnlRadioListComponent ]
})
export class RnlRadioListModule {
}
