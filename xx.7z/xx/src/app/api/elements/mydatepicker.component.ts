import {
  Component,
  ElementRef,
  Renderer,
  AfterViewChecked,
  AfterViewInit,
  forwardRef,
  NgModule,
  HostListener,
} from '@angular/core';
import {NG_VALUE_ACCESSOR, ControlValueAccessor} from '@angular/forms';
import {CommonModule} from '@angular/common';
import {FormsModule} from '@angular/forms';
import {ViewFocusedElement} from '../model/viewfocus.element';
import {DomHandler} from '../service/domhandler.service';
import * as moment from 'moment';
import {LoggingService} from '../service/logging.service';
import {ViewCommon} from '../service/viewcommon.service';
import {DatepickerModule} from "ng2-bootstrap";

const RNL_VALUE_ACCESSOR: any = {
  provide: NG_VALUE_ACCESSOR,
  useExisting: forwardRef(() => MyRnlDatePickerComponent), useMulti: true
};

declare var $: any;


@Component({
  selector: 'my-rnl-datepicker',
  template: `
        <div class="input-group">
          <input type="text" id="tbxDate" (keypress)="eventHandlerInputKeyPress($event)"
            class="form-control" [(ngModel)]="dateModel" (change)="changeValue($event)"
             (blur)="onTouchedCallback()" [disabled]="!enabled"/>
          <div class="input-group-btn">
            <button class="btn" (click)="showCalendar()" [disabled]="!enabled">
                <i class="fa fa-calendar"></i></button>
          </div>
        </div>
        <div id="calendar-popup" class="calendar-popup" tabindex="0" 
              [style.display]="panelVisible ? 'block' : 'none'" >
              
               <datepicker     [initDate]="value" (selectionDone)=\"onSelectionDone($event)\" [(ngModel)]="value" [showWeeks]="false" (ngModelChange)="changeModel($event)"  startingDay="1"   ></datepicker>
            
        </div>
      `,
  providers: [RNL_VALUE_ACCESSOR]
})
export class MyRnlDatePickerComponent extends ViewFocusedElement implements ControlValueAccessor,
  AfterViewChecked, AfterViewInit {

  // @Input()
  value: any;
  dateModel: any;
  // input: any;
  panel: any;
  datePickerPageShown: any;
  panelVisible: boolean;
  documentClickListener: any;
  width: string;
  isShowing: boolean;
  selectionDate: Date;
  input: HTMLInputElement;
  private myDatePickerOptions = {
    todayBtnTxt: 'Today',
    dateFormat: 'DD/MM/YYYY',
    dateFormaDayAndYear: 'MM/YYYY',
    firstDayOfWeek: 'mo',
    background: '#3BAFDA',
    showTextBox: false,
  };



  eventHandlerInputKeyPress(event) {
    console.log(event, event.keyCode, event.keyIdentifier);
  }

  constructor(private domHandler: DomHandler,
              private el: ElementRef,
              private renderer: Renderer,
              private log: LoggingService,
              viewCommon: ViewCommon) {
    super();
    this.panelVisible = false;
    this.id = this.el.nativeElement.id;
    viewCommon.registerComponentElement(this);
  }

  @HostListener('click', ['$event'])
  onClick(e: Event) {
    if (this.panelVisible) {
      console.log('dtp prevent default', this.panelVisible);
      e.preventDefault();
      e.stopPropagation();
    }
  }


  ngAfterViewChecked() {

    if(this.domHandler.findSingle(this.el.nativeElement, 'daypicker').childElementCount > 0 ){
      this.datePickerPageShown =  'DP_DAYS';
    }else if(this.domHandler.findSingle(this.el.nativeElement, 'monthpicker').childElementCount > 0 ){
      this.datePickerPageShown =  'DP_MONTH';
    }else if(this.domHandler.findSingle(this.el.nativeElement, 'yearpicker').childElementCount > 0 ){
      this.datePickerPageShown = 'DP_YEARS';
    }else {
      console.error("datePickerPageShown"+this.datePickerPageShown);
    }
    }

  ngOnInit() {
    console.log("hello world");

    let inputx = this.el.nativeElement.querySelector('input');
    let inputxx = this.el.nativeElement.querySelector('input');

    console.log(inputx);
    console.log(inputx);

    this.input = this.domHandler.findSingle(this.el.nativeElement, 'input');
    console.log(this.domHandler.findSingle(this.el.nativeElement, 'daypicker'));
    this.documentClickListener = this.renderer.listenGlobal('body', 'click', (e) => {
      let sourceEl = e.srcElement;
      console.log('DTP get closest...');
      if (this.domHandler.getClosest(sourceEl, '#calendar-popup') === null) {
        this.hide();
      }
      return true;
    });
  }

  ngAfterViewInit() {
    this.panel = this.domHandler.findSingle(this.el.nativeElement, 'div.calendar-popup');
    console.log('DateTimePicker AfterInit', this.input, this.panel);
    if (this.value) {
      this.selectionDate =
        moment(this.input.value, this.myDatePickerOptions.dateFormat).toDate();
      this.input.value = this.converFromDate(this.value); // Change here for date type
    }
  }

  converFromDate(value: any): string {
    if (value instanceof Date) {
      return moment(value).format(this.myDatePickerOptions.dateFormat);
    } else {
      return value;
    }
  }

  convertToDate(value: any): Date {
    if (value instanceof Date) {
      return value;
    }
    return moment(value, this.myDatePickerOptions.dateFormat).toDate();
  }

  align() {
    this.domHandler.relativePosition(this.panel, this.el.nativeElement.children[0]);
  }

  showCalendar() {

    this.domHandler.findSingle(this.el.nativeElement, 'div.calendar-popup').focus();

    console.info( this.domHandler.findSingle(this.el.nativeElement, 'div.calendar-popup'));
    console.info('show is called');
    this.isShowing = true;
    if (!this.panelVisible) {
      console.log('dtp showing...');
      this.panelVisible = true;
      this.panel.style.zIndex = 1000; // ++PUI.zindex;
      this.align();
      this.domHandler.fadeIn(this.panel, 300);
    }
  }

  hide() {
    // console.log('Hiding component...');
    // if(!this.isShowing) {
    //   this.panelVisible = false;
    // }
    // this.isShowing = false;
    this.panelVisible = false;
  }

  selectDate(e: any) {
    let value = this.convertToDate(e); // moment(e).format(this.myDatePickerOptions.dateFormat);
    this.onChangeCallback(value); // Change here for date type...
    this.input.value = this.converFromDate(value);
    this.hide();
  }

  ngOnDestroy() {
    if (this.documentClickListener) {
      this.documentClickListener();
    }
  }



  // From ControlValueAccessor interface
  writeValue(value: any) {
    if (value !== this.value) {
      this.value = this.convertToDate(value);
      this.input.value = this.converFromDate(value); // change here for date type...
      this.selectionDate = moment(this.converFromDate(value),
        this.myDatePickerOptions.dateFormat).toDate();
      this.log.debug('write value', this.value, this.selectionDate);
    }
  }

  // From ControlValueAccessor interface
  registerOnChange(fn: any) {
    this.onChangeCallback = fn;
  }

  // From ControlValueAccessor interface
  registerOnTouched(fn: any) {
    this.onTouchedCallback = fn;
  }

  changeValue(e: any) {
    this.onChangeCallback(e.srcElement.value); // change here for date type...
    this.selectionDate =
      moment(e.srcElement.value, this.myDatePickerOptions.dateFormat).toDate();
  }


  changeModel(event) {
    console.log("info" + event)
    if (this.datePickerPageShown == 'DP_DAYS') {
      this.dateModel = moment(event).format(this.myDatePickerOptions.dateFormat);
      this.hide()
    }

    //
    /* this.showDatepicker = false;
     this.dateModel = event;
     this.dateModelChange.emit(event)*/
  }


  onSelectionDone(event) {
    console.log("onSelectionDone" + event)
      this.dateModel = moment(event).format(this.myDatePickerOptions.dateFormat);
    }




  @HostListener('keydown', ['$event'])
  onKeyDown(e: KeyboardEvent) {
    let element: Element = e.srcElement;
    console.info(element);

    // key down
    if ( !this.panelVisible  && (e.keyCode === 40 || e.keyCode === 38) ) {
      this.showCalendar();

    }else if(!this.panelVisible){

      return false;
    }

    $(this.domHandler.findSingle(this.el.nativeElement, 'daypicker')).find('button.btn-info').removeClass('btn-info');


    // enter
    if (e.keyCode === 13) {
      this.changeModel(this.value);
      console.info("xxxxxxxxxx")
      $(this.domHandler.findSingle(this.el.nativeElement, 'daypicker')).find('button.btn-info').removeClass('btn-info');
      $(this.domHandler.findSingle(this.el.nativeElement, 'daypicker')).find('button.active').addClass('btn-info');

    }


    // btn btn-default btn-secondary btn-sm
    // btn btn-default btn-secondary btn-sm pull-left


    // key down
    if (e.keyCode === 40) {
      this.value = moment(this.value).add('days', +7).toDate();
    }
    // Key up
    if (e.keyCode === 38) {
      this.value = moment(this.value).add('days', -7).toDate();
    }
    //Key right
    if (e.keyCode === 39) {
      this.value = moment(this.value).add('days', +1).toDate();
    }
    //page left
    if (e.keyCode === 37 ) {
      this.value = moment(this.value).add('days', -1).toDate();
    }
    //echap
    if (e.keyCode === 27 ) {
      this.hide();
    }


    // key down
    if ( !this.panelVisible  && (e.keyCode === 40 || e.keyCode === 38) ) {
     this.showCalendar();

    }



    console.info('------------------------------------------');
    console.info(e.keyCode);
    console.info(this.value);
    console.info('------------------------------------------');

    return false;


  }

  // Placeholders for the callbacks which are later providesd
  // by the Control Value Accessor
  private onTouchedCallback: Function = () => {
  };
  private onChangeCallback: Function = (value: any) => {
  };

}

@NgModule({
  exports: [MyRnlDatePickerComponent],
  declarations: [MyRnlDatePickerComponent],
  imports: [CommonModule, FormsModule, DatepickerModule]
})
export class MyRnlDatePickerModule {
}
