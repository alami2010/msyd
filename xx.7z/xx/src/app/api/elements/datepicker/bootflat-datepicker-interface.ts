export interface MyDate {
  year: number;
  month: number;
  day: number;
}

export interface MyMonth {
  monthTxt: string;
  monthNbr: number;
  year: number;
}
