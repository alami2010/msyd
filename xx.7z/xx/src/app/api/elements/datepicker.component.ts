import {
    Component,
    ElementRef,
    Renderer,
    AfterViewChecked,
    AfterViewInit,
    forwardRef,
    NgModule,
    HostListener,
} from '@angular/core';
import { NG_VALUE_ACCESSOR, ControlValueAccessor } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ViewFocusedElement } from '../model/viewfocus.element';
import { DomHandler } from '../service/domhandler.service';
import * as moment from 'moment';
import { LoggingService } from '../service/logging.service';
import { ViewCommon } from '../service/viewcommon.service';
import { BootFlatDatePickerInnerModule } from './datepicker/bootflat-datepicker.component';

const RNL_VALUE_ACCESSOR: any = {
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => RnlDatePickerComponent), useMulti: true
};

@Component({
    selector: 'rnl-datepicker',
    template: `
        <div class="input-group">
          <input type="text" id="tbxDate"
            class="form-control" (change)="changeValue($event)"
             (blur)="onTouchedCallback()" [disabled]="!enabled"/>
          <div class="input-group-btn">
            <button class="btn" (click)="show()" [disabled]="!enabled">
                <i class="fa fa-calendar"></i></button>
          </div>
        </div>
        <div id="calendar-popup" class="calendar-popup"
              [style.display]="panelVisible ? 'block' : 'none'" 
              [style.width]="width" >
              <bootflat-date-picker [options]="myDatePickerOptions" 
                (dateChanged)="selectDate($event)" [(selDate)]="selectionDate">
                </bootflat-date-picker>
          
        </div>
      `,
    providers: [ RNL_VALUE_ACCESSOR ]
})
export class RnlDatePickerComponent extends ViewFocusedElement implements ControlValueAccessor,
    AfterViewChecked, AfterViewInit {

    // @Input()
    value: any;
    // input: any;
    panel: any;
    panelVisible: boolean;
    documentClickListener: any;
    width: string;
    isShowing: boolean;
    selectionDate: Date;
    input: HTMLInputElement;
    private myDatePickerOptions = {
        todayBtnTxt: 'Today',
        dateFormat: 'DD/MM/YYYY',
        firstDayOfWeek: 'mo',
        sunHighlight: true,
        height: '134px',
        width: '300px',
        background: '#3BAFDA',
        showTextBox: false,
    };

    constructor(private domHandler: DomHandler,
                private el: ElementRef,
                private renderer: Renderer,
                private log: LoggingService,
                viewCommon: ViewCommon) {
        super();
        this.panelVisible = false;
        this.width = '225px';
        this.id = this.el.nativeElement.id;
        viewCommon.registerComponentElement(this);
    }

    @HostListener('click', [ '$event' ])
    onClick(e: Event) {
        if (this.panelVisible) {
            // console.log('dtp prevent default', this.panelVisible);
            e.preventDefault();
            e.stopPropagation();
        }
    }

    ngOnInit() {
        this.input = this.domHandler.findSingle(this.el.nativeElement, 'input');
        this.documentClickListener = this.renderer.listenGlobal('body', 'click', (e) => {
            let sourceEl = e.srcElement;
            console.log('DTP get closest...');
            if (this.domHandler.getClosest(sourceEl, '#calendar-popup') === null) {
                this.hide();
            }
            return true;
        });
    }

    ngAfterViewInit() {
        this.panel = this.domHandler.findSingle(this.el.nativeElement, 'div.calendar-popup');
        console.log('DateTimePicker AfterInit', this.input, this.panel);
        if (this.value) {
            this.selectionDate =
                moment(this.input.value, this.myDatePickerOptions.dateFormat).toDate();
            this.input.value = this.converFromDate(this.value); // Change here for date type
        }
    }

    converFromDate(value: any): string {
        if (value instanceof Date) {
            return moment(value).format(this.myDatePickerOptions.dateFormat);
        } else {
            return value;
        }
    }

    convertToDate(value: any): Date {
        if (value instanceof Date) {
            return value;
        }
        return moment(value, this.myDatePickerOptions.dateFormat).toDate();
    }

    align() {
        this.domHandler.relativePosition(this.panel, this.el.nativeElement.children[ 0 ]);
    }

    show() {
        this.isShowing = true;
        if (!this.panelVisible) {
            console.log('dtp showing...');
            this.panelVisible = true;
            this.panel.style.zIndex = 1000; // ++PUI.zindex;
            this.align();
            this.domHandler.fadeIn(this.panel, 200);
        }
    }

    hide() {
        // console.log('Hiding component...');
        // if(!this.isShowing) {
        //   this.panelVisible = false;
        // }
        // this.isShowing = false;
        this.panelVisible = false;
    }

    selectDate(e: any) {
        let value = this.convertToDate(e); // moment(e).format(this.myDatePickerOptions.dateFormat);
        this.onChangeCallback(value); // Change here for date type...
        this.input.value = this.converFromDate(value);
        this.hide();
    }

    ngOnDestroy() {
        if (this.documentClickListener) {
            this.documentClickListener();
        }
    }

    ngAfterViewChecked() {
        // this.align();
    }

    // From ControlValueAccessor interface
    writeValue(value: any) {
        if (value !== this.value) {
            this.value = this.convertToDate(value);
            this.input.value = this.converFromDate(value); // change here for date type...
            this.selectionDate = moment(this.converFromDate(value),
                this.myDatePickerOptions.dateFormat).toDate();
            this.log.debug('write value', this.value, this.selectionDate);
        }
    }

    // From ControlValueAccessor interface
    registerOnChange(fn: any) {
        this.onChangeCallback = fn;
    }

    // From ControlValueAccessor interface
    registerOnTouched(fn: any) {
        this.onTouchedCallback = fn;
    }

    changeValue(e: any) {
        this.onChangeCallback(e.srcElement.value); // change here for date type...
        this.selectionDate =
            moment(e.srcElement.value, this.myDatePickerOptions.dateFormat).toDate();
    }

    // Placeholders for the callbacks which are later providesd
    // by the Control Value Accessor
    private onTouchedCallback: Function = () => {
    };
    private onChangeCallback: Function = (value: any) => {
    };

}

@NgModule({
    exports: [ RnlDatePickerComponent ],
    declarations: [ RnlDatePickerComponent ],
    imports: [ CommonModule, FormsModule, BootFlatDatePickerInnerModule ]
})
export class RnlDatePickerModule {
}
