import { Component, ElementRef, OnInit, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ViewListElement } from '../model/viewlist.element';
import { ViewCommon } from '../service/viewcommon.service';
import { FocusDirectiveModule } from './focus.directive';

declare var $: any;

@Component({
    selector: 'rnl-listselect',
    template: `
    <select [attr.class]="classes" 
        [attr.size]="size" [rnl-focused]="focused" (change)="selectItem($event)">
      <option *ngFor="let node of list" [attr.value]="node.key">{{node.value}}</option>
    </select>
  `
})
export class ListSelectComponent extends ViewListElement implements OnInit {

    constructor(private el: ElementRef, private viewCommon: ViewCommon) {
        super();
        this.id = this.el.nativeElement.id;
        this.viewCommon.registerComponentElement(this);
        this.classList.push('form-control');
    }

    ngOnInit() {
        if (this.value) {
            if (this.list) {
                // Select item...
            }
        }
        if (this.list) {
            this.value = this.list[ 0 ].key;
        }
    }

    selectItem(e: any) {
        this.value = e.target.value;
    }
}

@NgModule({
    declarations: [ ListSelectComponent ],
    exports: [ ListSelectComponent ],
    imports: [ CommonModule, FocusDirectiveModule ]
})
export class ListSelectModule {

}

