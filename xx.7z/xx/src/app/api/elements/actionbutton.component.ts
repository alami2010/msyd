import {
    Component,
    OnInit,
    ElementRef,
    Output, EventEmitter, Input, NgModule
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { ButtonElement } from '../model/button.element';
import { ViewCommon } from '../service/viewcommon.service';
import { LoggingService } from '../service/logging.service';
import { FocusDirectiveModule } from './focus.directive';


@Component({
    selector: 'rnl-button',
    template: `
      <button [attr.class]="classes" *ngIf="visible"
        (click)="eventClick($event)" 
        tabindex="0" 
        [rnl-focused]="focused" 
        [attr.alt]="value"
        [disabled]="!enabled">{{value}}</button> 
    `
})
export class ActionButtonComponent extends ButtonElement implements OnInit {

    @Input()
    text: string;

    @Input()
    isPrimary: boolean;

    @Output()
    clickEvent: EventEmitter<any> = new EventEmitter(false);

    @Input()
    enabled: boolean;

    constructor(private el: ElementRef,
                private viewCommon: ViewCommon,
                private log: LoggingService) {
        super();
        this.id = el.nativeElement.id;
        /* this.classList.push('btn-block'); */
        this.classList.push('btn-sm');
        this.viewCommon.registerComponentElement(this);
        if (typeof this.enabled === 'undefined') {
            this.enabled = true;
        }
    }

    ngOnInit() {
        if (!this.value && this.text) this.value = this.text;
        console.log('Button text', this.value);
        if (this.isPrimary) {
            this.primary = true;
            this.default = false;
        } else {
            this.primary = false;
            this.default = true;
        }

        // Button layout.
        let isBlockLayout: boolean = false;
        this.log.debug('testing parent element', this.el.nativeElement.parentElement.classList);
        for (let cls of this.el.nativeElement.parentElement.classList) {
            if (cls === 'rdmq_right_m' || cls === 'rdmq_right_l') {
                isBlockLayout = true;
            }
        }
        // this.el.nativeElement.parentElement.classList.forEach(v => {
        //   if (v === 'rdmq_right_m' || v === 'rdmq_right_l') {
        //     isBlockLayout = true;
        //   }
        // });
        if (!isBlockLayout) this.classList.push('btn-block');

    }

    eventClick(e: any) {
        console.log('Event Clicked', e);
        this.clickEvent.emit({e: e});
    }
}

@NgModule({
    imports: [ CommonModule, FocusDirectiveModule ],
    exports: [ ActionButtonComponent ],
    declarations: [ ActionButtonComponent ]
})
export class ActionButtonModule {}
