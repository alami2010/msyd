import { Injectable } from '@angular/core';
import {
    CanActivate, Router,
    ActivatedRouteSnapshot,
    RouterStateSnapshot
} from '@angular/router';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import { Http, Headers, RequestOptions } from '@angular/http';
import { AsyncRequest } from '../model/security/asyncrequest.model';
import { ViewCommon } from './viewcommon.service';

@Injectable()
export class AuthGard implements CanActivate {

    constructor(private http: Http, private viewCommon: ViewCommon) {
    }

    canActivate(route: ActivatedRouteSnapshot,
                state: RouterStateSnapshot): Observable<boolean>|Promise<boolean>|boolean {
        let viewNum = route.component[ 'name' ].replace(/[A-z]+/g, '')
        let viewId = route.component[ 'name' ][ 0 ] + viewNum;
        console.log('Checking gard!', viewId);
        return this.checkGard(viewId);
    }

    private checkGard(viewId: string): Observable<boolean> {
        let headers = new Headers({'Content-Type': 'application/json', 'x-option-guard': 'true'});
        let options = new RequestOptions({headers: headers});
        console.log('In gard!', viewId);
        // noinspection TypeScriptUnresolvedFunction
        let request: AsyncRequest<any> = new AsyncRequest<any>();
        request.viewId = viewId;
        request.auditInformation = window.navigator.userAgent;
        // noinspection TypeScriptUnresolvedFunction
        return this.http.post('/api/secure/checkgard', JSON.stringify(request), options)
            .map(res => res[ 'data' ]);
    }
}

