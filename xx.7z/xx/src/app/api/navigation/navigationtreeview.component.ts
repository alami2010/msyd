import { Component, Input, OnInit, ElementRef, NgModule, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterStateSnapshot } from '@angular/router';
import { NodeModel } from './model/node.model';
import { ViewTreeElement } from '../model/viewtree.element';
import { ViewCommon } from '../service/viewcommon.service';
import { PluginService } from '../plugins/plugin.service';
import { NodeService } from './services/node.service';
import { ActivatedRoute, Router } from '@angular/router';
import { ActiveLinkModule } from './activelink.directive';
import { TreeViewKeyModule } from './treeviewkey.directive';
import { FocusDirectiveModule } from '../elements/focus.directive';

@Component({
    selector: 'navigation-tree',
    templateUrl: './navigationtreeview.template.html',
})
export class NavigationTreeViewComponent extends ViewTreeElement implements OnInit {

    focusedElement: Element;

    @ViewChild('treeNode') treeNode: any;

    @Input()
    treeNodes: NodeModel[];

    constructor(el: ElementRef,
                viewCommon: ViewCommon,
                private pluginService: PluginService,
                private nodeService: NodeService,
                private route: ActivatedRoute,
                private router: Router) {
        super();
        this.id = el.nativeElement.id;
        viewCommon.registerComponentElement(this);
    }

    ngOnInit(): any {
        this.pluginService.applyNavigationTreeViewScroll();
        // console.log('Initializing node', this.treeNodes);
        if (this.treeNodes && this.treeNodes.length > 0) {
            // Only do that for a first level node
            if (this.treeNodes[ 0 ].parent && this.treeNodes[ 0 ].parent.parent === null) {
                console.log('Tree View Select state in view',
                    this.router.url);
                this.nodeService.selectStateInView(this.treeNodes[ 0 ].parent,
                    this.router.url /* this.state.$current */);
            }
        }
        console.log('View child', this.treeNode);
        return undefined;
    }

    clickFocused(node: NodeModel, e: Event) {
        this.nodeService.activateNode(node);
        this.focusedElement = e.srcElement;
    }

    expandReduce(node: NodeModel, e: Event) {
        // maybe a broadcast to close first level should do it.
        this.focusedElement = e.srcElement;
        if (node.visible && node.enabled && node.children) {
            node.expanded = !node.expanded;
        }
    }
}
@NgModule({
    declarations: [ NavigationTreeViewComponent ],
    imports: [ CommonModule, TreeViewKeyModule, ActiveLinkModule, FocusDirectiveModule ],
    exports: [ NavigationTreeViewComponent ]
})
export class NavigationTreeViewModule {
}
