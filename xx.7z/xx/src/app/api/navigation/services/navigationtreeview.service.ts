import { Injectable } from '@angular/core';

// noinspection TypeScriptUnresolvedFunction
require('./../../plugins/slimScroll');

declare var window: any;
declare var document: any;
declare var $: any;
declare var jQuery: any;

@Injectable()
export class NavigationTreeViewService {
}
