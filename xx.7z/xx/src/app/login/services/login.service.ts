import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs';
import { UserModel } from '../../api/model/security/user.model';

@Injectable()
export class LoginService {

    public static token: any;

    /**
     *
     */
    public constructor(private http: Http) {
    }

    /**
     * Login service.
     * @param userId
     * @param password
     * @returns {Observable<UserModel>}
     */
    public login(userId: string, password: string): Observable<UserModel> {
        let headers = new Headers({
            'Content-Type': 'application/json',
            'Authorization': ' Basic ' + btoa(userId + ':' + password)
        });

        let options = new RequestOptions({headers: headers});
        // noinspection TypeScriptUnresolvedFunction
        return this.http.post('/api/auth', null, options).map(r => r[ 'data' ]);
    }

    public refreshToken(): Observable<any> {
        let headers = new Headers({
            'Content-Type': 'application/json',
        });
        let options = new RequestOptions({headers: headers});
        // noinspection TypeScriptUnresolvedFunction
        return this.http.get('/api/token', options).map(r => r);
    }
}
