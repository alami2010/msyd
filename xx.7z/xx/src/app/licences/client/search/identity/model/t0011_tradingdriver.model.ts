import { ViewModel } from '../../../../../api/model/view.model';
import { ViewListElement } from '../../../../../api/model/viewlist.element';
import { ViewFocusedElement } from '../../../../../api/model/viewfocus.element';
import { KeyValueModel } from '../../../../../api/model/keyvalue.model';
import { CheckboxListComponent } from '../../../../../api/elements/chekcboxlist.component';

export class T0011TradingDriverModel extends ViewModel {
    rdlDriverType: ViewListElement;
    rdlMaleFemal: ViewListElement;
    ckcValidBound: ViewFocusedElement;
    ckcListDays: CheckboxListComponent;
    cklSemesters: CheckboxListComponent;

    driverType: number;
    maleFemal: string;
    licenceValid: boolean;
    otherValue: boolean;
    daysOfWeek: KeyValueModel[];
    selectedSemesters: KeyValueModel[];
}
