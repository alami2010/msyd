import { Component } from '@angular/core';
import { T0010TrandingIdentityModel } from './model/t0010_tradingidentity.model';
import { ViewCommon } from '../../../../api/service/viewcommon.service';
import { IdentityService, IDENTITY_SERVICE_PROVIDER } from './services/identity.service';

@Component({
    selector: 't0010-trading-identity',
    templateUrl: './t0010_tradingidentity.template.html',
    providers: [
        IDENTITY_SERVICE_PROVIDER
    ]
})
export class T0010TradingIdentity extends T0010TrandingIdentityModel {

    constructor(viewCommon: ViewCommon, private identityService: IdentityService) {
        super();
        this.id = 'T0010';
        viewCommon.registerComponent(this);
    }

    ngOnInit() {
        this.identityService.loadTreeView(this);
    }

}
