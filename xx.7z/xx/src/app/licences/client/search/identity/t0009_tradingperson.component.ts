import { Component } from '@angular/core';
import { T0009TradingPersonModel } from './model/t0009_tradingperson.model';
import { ViewCommon } from '../../../../api/service/viewcommon.service';
import { IDENTITY_SERVICE_PROVIDER, IdentityService } from './services/identity.service';
import { ToasterService } from '../../../../api/toaster/toaster.service';
import { ValidationItem, ValidationType } from '../../../../api/model/validation.model';
import { LoggingService } from '../../../../api/service/logging.service';
import { ValidationService } from '../../../../api/elements/service/validation.service';

declare var $: any;

@Component({
    selector: 't0009-trading-person',
    templateUrl: './t0009_tradingperson.template.html',
    providers: [ IDENTITY_SERVICE_PROVIDER ]
})
export class T0009TradingPerson extends T0009TradingPersonModel {

    constructor(private viewCommon: ViewCommon,
                private toasterService: ToasterService,
                private log: LoggingService,
                private validationService: ValidationService) {
        super();
        this.id = 'T0009';
        this.viewCommon.registerComponent(this);

        this.dateFormat = new Date();
        this.numberFormat = 3.1415927;
        this.currencyFormat = 125.05652;
        this.dateString = '25/09/2017';
    }

    ngOnInit() {
        let valRegexTwo = new ValidationItem(ValidationType.REGEX, 'The word two must be present');
        valRegexTwo.regex = 'w*(two)';
        this.tbxRnlTwo.validation.validations
            .push(new ValidationItem(ValidationType.REQUIRED,
                'Component Two is required, please enter a value.'));
        this.tbxRnlTwo.validation.validations.push(valRegexTwo);

        let valUserAgeLt = new ValidationItem(ValidationType.MAX, 'User age must be less than 24');
        valUserAgeLt.range = 24;
        this.tbxUserAgeLt.validation.validations.push(valUserAgeLt);

        let valUserAgeGt = new ValidationItem(ValidationType.MIN,
            'User age must be greater than 18');
        valUserAgeGt.range = 18;
        this.tbxUserAgeGt.validation.validations.push(valUserAgeGt);

        let valEmail = new ValidationItem(ValidationType.REGEX, 'A valid EMail is required.');
        valEmail.regex = "[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)" +
            '*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?';
        this.tbxEmail.validation.validations.push(valEmail);

        this.customValidation.bind(this); // Bind the function to the class.
        this.tbxInputReq.validation.validations.push(new ValidationItem(ValidationType.REQUIRED,
            'Text is required, please enter a value.'));
        let valCustom = new ValidationItem(ValidationType.CUSTOM,
            'If sum of age are 42, the field value must contain 42.');
        valCustom.custom = this.customValidation;
        this.tbxInputReq.validation.validations.push(valCustom);

        // Combo box:
        this.cbxSelectOption.list.push({key: 'AAC', value: 'Ashmore and Cartier Islands'});
        this.cbxSelectOption.list.push({key: 'AAT', value: 'Australian Antarctic Territory'});
        this.cbxSelectOption.list.push({key: 'ACT', value: 'Australian Capital Territory'});
        this.cbxSelectOption.list.push({key: 'CIS', value: 'Christmas Island'});
        this.cbxSelectOption.list.push({key: 'CKI', value: 'Cocos (Keeling) Islands'});
        this.cbxSelectOption.list.push({key: 'CSI', value: 'Coral Sea Islands'});
        this.cbxSelectOption.list.push({key: 'HIM', value: 'Heard Island and McDonald Islands'});
        this.cbxSelectOption.list.push({key: 'JBT', value: 'Jervis Bay Territory'});
        this.cbxSelectOption.list.push({key: 'NSW', value: 'New South Wales'});
        this.cbxSelectOption.list.push({key: 'NIS', value: 'Norfolk Island'});
        this.cbxSelectOption.list.push({key: 'NTE', value: 'Northern Territory'});
        this.cbxSelectOption.list.push({key: 'QLD', value: 'Queensland'});
        this.cbxSelectOption.list.push({key: 'SAU', value: 'South Australia'});
        this.cbxSelectOption.list.push({key: 'TAS', value: 'Tasmania'});
        this.cbxSelectOption.list.push({key: 'VIC', value: 'Victoria'});
        this.cbxSelectOption.list.push({key: 'WAU', value: 'Western Australia'});

        this.cbxRequired.validation.validations.push(new ValidationItem(ValidationType.REQUIRED,
            'Option is required, please enter a value.'));
        this.cbxRequired.list.push({key: 'D', value: 'Required value'});

        this.cbxSelectOptionValue = {key: 'VIC', value: 'Victoria'};

        this.selectOption = this.cbxSelectOptionValue.key;
        this.optionRequired = '';

        this.dtpReceived.enabled = true;
        this.ckcDtpReceived.value = true;
        this.enableSelectOption = false;
    }

    /**
     * This is the only to retain the execution context 'this' for a callback function.
     * @param value
     * @returns {boolean}
     */
    customValidation = (value: string): boolean => {
        let sum: number = Number(this.tbxUserAgeGt.value) + Number(this.tbxUserAgeLt.value);
        this.log.debug('Sum of ages', sum);
        if (sum === 42 && value.indexOf('42') < 0) {
            this.log.debug('String must contain 42', value);
            return false;
        }
        return true;
    }

    showInfoToast() {
        this.toasterService.pop('success', 'Success info...',
            'You have click the success button, thank you! ' +
            'This message will disappear in 20seconds. ' +
            'Take your time to read it. ');
    }

    showErrorToast() {
        this.toasterService.pop('error', 'Error info...',
            'You have click the error button, thank you! ' +
            'This message won\'t go away. You will need to manually close it. ' +
            'Take your time to read it. ');
    }

    isDate(value: any) {
        return value instanceof Date;
    }

    showModal() {
        $('#slide-bottom-popup').modal('show');
    }

    validateForm() {
        this.validationService.viewValidation();
        if (this.valid) {
            this.log.debug('Form is valid');
            this.toasterService.pop('success', 'Validation',
                'Congratulation, the form is valid.');
        } else {
            this.toasterService.pop('error', 'Validation',
                'The form is invalid, please check your entries.');
        }
    }

    checkBoxChange(e: boolean) {
        this.dtpReceived.enabled = e;
    }

}
