import { ViewModel } from '../../../../../api/model/view.model';
import { NavigationTreeViewComponent } from '../../../../../api/navigation/navigationtreeview.component';
import { ActionButtonComponent } from '../../../../../api/elements/actionbutton.component';
import { NodeModel, NodeType } from '../../../../../api/navigation/model/node.model';

export class T0010TrandingIdentityModel extends ViewModel {
    ntvDemeritPoints: NavigationTreeViewComponent;
    btnAddBan: ActionButtonComponent;
    btnToHistorical: ActionButtonComponent;
    btnButton: ActionButtonComponent;

    public displayButtons: Function = (node: NodeModel): void => {
        this.btnAddBan.visible = false;
        this.btnToHistorical.visible = false;
        this.btnButton.visible = false;
        console.log('Display group', node.type);
        if (node.type === NodeType.GROUP_TWO) {
            this.btnButton.visible = true;
        } else if (node.type === NodeType.GROUP_THREE) {
            this.btnButton.visible = true;
            this.btnAddBan.visible = true;
        } else if (node.type === NodeType.GROUP_FOUR) {
            this.btnToHistorical.visible = true;
        }
    }
}
