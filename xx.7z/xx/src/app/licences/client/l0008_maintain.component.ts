import { Component, OnInit, AfterViewInit } from '@angular/core';
import { ViewCommon } from '../../api/service/viewcommon.service';
import { ViewModel } from '../../api/model/view.model';
import { PluginService } from '../../api/plugins/plugin.service';
import { ToasterService } from '../../api/toaster/toaster.service';
import { EventsCommon } from '../../api/service/eventcommon.service';

declare var $: any;
declare var jQuery: any;

@Component({
    selector: 'l0008-selector',
    providers: [ ViewCommon ],
    templateUrl: './l0008_maintain.template.html',
    styles: [ `.superscript {
    font-size: .83em;
    line-height: 0.5em;
    vertical-align: baseline;
    position: relative;
    top: -0.4em;
    color: #aade80;
}` ]
})
export class L0008MaintainComponent extends ViewModel implements OnInit,  AfterViewInit {

    constructor(private viewCommon: ViewCommon,
                private pluginService: PluginService,
                private eventCommon: EventsCommon,
                private toasterService: ToasterService) {
        super();
        this.id = 'L0008';
        this.viewCommon.registerComponent(this);
    }

    ngOnInit() {
        // Skin for checkboxes and radio buttons
        this.pluginService.icheckInit();
    }

    ngAfterViewInit() {
        this.eventCommon.broadcast(EventsCommon.UPDATE_NAVIGATION_TREE, '/l0008maintain');
    }

    showSuccess() {
        this.toasterService.pop('success',
            'Information Messages',
            'RnL - Client loaded on context.');
    }

    showError() {
        this.toasterService.pop('error',
            'Error Messages',
            'RnL - Error #CMC00176 - No open client found.');
    }

    showModal() {
        $('#slide-bottom-popup').modal('show');
    }

    changeMail(e: any) {
        console.log('Email', e);
    }

}
