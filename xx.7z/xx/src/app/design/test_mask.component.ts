import {ViewCommon} from "../api/service/viewcommon.service";
import {Component, NgModule, Input} from "@angular/core";
import {ViewModel} from "../api/model/view.model";
import {MaskSelector, MaskSelectorModule} from "../api/elements/mask-input.directive";
declare var $: any;

@Component({
  selector: 'test-mask',
  template: `<div class="panel panel-default">
  <div class="panel-heading">Form controls</div>
<div class="panel-body">
<div class="row">

<div class="form-group">
<label class="control-label col-sm-3">Uer code</label>
<div class="col-sm-3">
<input type="text" id="tbxCode" class="form-control" [mask-input]="'999-AA-9'"/>
  </div>
  </div>
  </div>
  </div>
  </div>`,
  providers: [MaskSelector]
})

export class TestMaskComponent extends ViewModel {

  constructor(private viewCommon: ViewCommon) {
    super();
  }
}

@NgModule({
  declarations: [TestMaskComponent],
  exports: [TestMaskComponent],
  imports: [MaskSelectorModule]
})
export class TestMaskModule {
}
