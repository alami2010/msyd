import {Component, ViewChildren, QueryList, ElementRef, NgModule, OnInit} from "@angular/core";
import {ChildComponent} from "./child.component";
import {NgModel} from "@angular/forms";
import {RnlDatePickerComponent} from "../api/elements/datepicker.component";
import {ViewModel} from "../api/model/view.model";
import {ViewCommon} from "../api/service/viewcommon.service";
import {CommonModule} from "@angular/common";
import {InfoModule} from "./info.component";
import {FormControlModule, FormControlComponent} from "../api/elements/formcontrol.component";

import {ActionButtonModule} from "../api/elements/actionbutton.component";

import {TestMaskModule} from "./test_mask.component";
import {TextBoxComponent, TextBoxModule} from "./textbox.component";




@Component({
  moduleId: module.id,
  selector: 'main-component',
  templateUrl: 'main.component.html'
})

export class MainComponent extends ViewModel {
  private loginId: string;
  private password: string;
  private fcLogin: FormControlComponent;
  private tbxLogin: TextBoxComponent;
  private fcPassword: FormControlComponent;
  private tbxPassword: TextBoxComponent;


  constructor(private viewCommon: ViewCommon) {
    super()
  }



}
@NgModule({
  exports: [MainComponent],
  declarations: [MainComponent],
  imports: [CommonModule, TextBoxModule, FormControlModule, ActionButtonModule,TestMaskModule]
})

export class MainModule {
}
