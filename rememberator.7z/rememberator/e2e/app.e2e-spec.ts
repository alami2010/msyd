import { RememberatorPage } from './app.po';

describe('rememberator App', function() {
  let page: RememberatorPage;

  beforeEach(() => {
    page = new RememberatorPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
