import { Component } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ViewModel } from '../api/model/view.model';
import { ViewCommon } from '../api/service/viewcommon.service';
import { EventsCommon } from '../api/service/eventcommon.service';
import { LoginService } from './services/login.service';
import { LoggingService } from '../api/service/logging.service';
import { Http } from '@angular/http';
import { AuthHttpService } from '../api/service/authhttp.service';
import { UserModel } from '../api/model/security/user.model';
import { DataStoreService } from '../api/service/datastore.service';


@Component({
    selector: 'l0009',
    templateUrl: './l0009_login.template.html',
})
export class L0009LoginComponent extends ViewModel {

    private loginId: string;
    private password: string;
    private authHttp: AuthHttpService;

    constructor(viewCommon: ViewCommon,
                private eventsCommon: EventsCommon,
                private loginService: LoginService,
                private log: LoggingService,
                private router: Router,
                private route: ActivatedRoute,
                private auth: Http,
                private dataStore: DataStoreService) {
        super();
        this.id = 'L0009';
        viewCommon.registerComponent(this);
        this.eventsCommon.broadcast(EventsCommon.UPDATE_LOGIN, false);
        this.authHttp = this.auth as AuthHttpService;
    }

    login() {
        // erase the token here.
        this.eventsCommon.broadcast(EventsCommon.AUTH_LOGOUT);
        let returnUrl = this.route.snapshot.params['returnUrl']
            ? atob(this.route.snapshot.params['returnUrl']) : null;
        this.dataStore.user = new UserModel(null, null, null);
        this.loginService.refreshToken().subscribe(t => {
            this.loginService.login(this.loginId, this.password).subscribe((r: UserModel) => {
                console.log('Result login', r);
                if (r && r.roles) {
                    this.eventsCommon.broadcast(EventsCommon.UPDATE_LOGIN, true);
                    this.eventsCommon.broadcast(EventsCommon.UPDATE_USER, r.name);
                    this.dataStore.user = r;
                    this.log.debug('User logged in', r.name, returnUrl);
                    if (returnUrl) {
                        console.log('Login Navigate to return url:', returnUrl);
                        this.router.navigate([ returnUrl ]);
                    } else {
                        this.router.navigate([ 'l0010messages' ]);
                    }
                }
            });
        });

    }
}
