import { Resolve, ActivatedRouteSnapshot, Router } from '@angular/router';
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/observable/of';
import { Observable } from 'rxjs/Observable';
import { AppState } from '../../app.service';
import { KeyValueModel } from '../../api/model/keyvalue.model';

@Injectable()
export class BranchResolver implements Resolve<any> {


    constructor(private router: Router, private appState: AppState) {

    }

    resolve(route: ActivatedRouteSnapshot) {
        console.log('Branch activation!');
        // if (route.params[ 'branchId' ]) {
        //     let branchId: number = +route.params[ 'branchId' ];
        //     this.router.navigate([ 'a0001licences', 'l0004licences' ]);
        //     // noinspection TypeScriptUnresolvedFunction
        //     return Observable.of(null);
        // }
        // noinspection TypeScriptUnresolvedFunction
        return Observable.of(this.buildBranch());
    }

    private buildBranch(): KeyValueModel[] {
        let result: KeyValueModel[] = [];
        result.push({key: 1, value: 'ISD - Data Analyst'});
        result.push({key: 2, value: 'ISD - Data Collection'});
        result.push({key: 3, value: 'ISD - Data Processing'});
        result.push({key: 4, value: 'ISD - Properly Enquiries'});
        result.push({key: 5, value: 'ISD - R+L Clearing'});
        result.push({key: 6, value: 'ISD - R+L Recds Manage'});
        result.push({key: 7, value: 'ISD - RAS'});
        result.push({key: 8, value: 'ISD - Road Info Clearing'});
        result.push({key: 9, value: 'Kerang Agency'});
        result.push({key: 10, value: 'Kew - Bookshop'});
        result.push({key: 11, value: 'Kew - Finance'});
        result.push({key: 12, value: 'R+L - Operations (Kew)'});
        result.push({key: 13, value: 'R+L - Policy'});
        result.push({key: 14, value: 'R+L - Projects'});
        result.push({key: 15, value: 'VicRoads Investigations'});
        return result;
    }
}
