import { Injectable } from '@angular/core';
import { KeyValueModel } from '../../api/model/keyvalue.model';
import { ListSelectComponent } from '../../api/elements/listselect.component';
import { DataStoreService } from '../../api/service/datastore.service';
import { BranchModel } from '../../api/model/domain/branch.model';
import { EventsCommon } from '../../api/service/eventcommon.service';
@Injectable()
export class BranchService {

    public constructor(private dataStoreSerivce: DataStoreService,
                       private eventsCommon: EventsCommon) {

    }

    public loadBranchOffices(branch: ListSelectComponent): void {
        branch.list = this.buildBranch();
    }

    public loadBranch(branch: ListSelectComponent): void {
        console.log('Loading branch data');
        if (branch.value) {
            // Refresh branch in case of reload.
            if (!branch.list) branch.list = this.buildBranch();
            branch.list.forEach(value => {
                if (String(branch.value) === String(value.key)) {
                    console.log('found branch', value);
                    this.dataStoreSerivce.branch = new BranchModel(value.key, value.value);
                    // Refresh header branch
                    this.eventsCommon.broadcast(EventsCommon.UPDATE_BRANCH,
                        value.value);
                    // this.eventsCommon.broadcast(EventsCommon.UPDATE_NAVIGATION_TREE,
                    //     'select-search');
                }
            });
        }
    }

    public loadBranchById(id: string) {
        console.log('Load branch by id', id);
        if (id) {
            let branches: KeyValueModel[] = this.buildBranch();
            branches.forEach(b => {
                if (id === String(b.key)) {
                    this.dataStoreSerivce.branch = new BranchModel(b.key, b.value);
                    // Refresh header branch
                    this.eventsCommon.broadcast(EventsCommon.UPDATE_BRANCH, b.value);
                }
            });
        }
    }

    private buildBranch(): KeyValueModel[] {
        let result: KeyValueModel[] = [];
        result.push({key: 1, value: 'ISD - Data Analyst'});
        result.push({key: 2, value: 'ISD - Data Collection'});
        result.push({key: 3, value: 'ISD - Data Processing'});
        result.push({key: 4, value: 'ISD - Properly Enquiries'});
        result.push({key: 5, value: 'ISD - R+L Clearing'});
        result.push({key: 6, value: 'ISD - R+L Recds Manage'});
        result.push({key: 7, value: 'ISD - RAS'});
        result.push({key: 8, value: 'ISD - Road Info Clearing'});
        result.push({key: 9, value: 'Kerang Agency'});
        result.push({key: 10, value: 'Kew - Bookshop'});
        result.push({key: 11, value: 'Kew - Finance'});
        result.push({key: 12, value: 'R+L - Operations (Kew)'});
        result.push({key: 13, value: 'R+L - Policy'});
        result.push({key: 14, value: 'R+L - Projects'});
        result.push({key: 15, value: 'VicRoads Investigations'});
        return result;
    }
}
