import { ViewModel } from '../../api/model/view.model';
import { ActionButtonComponent } from '../../api/elements/actionbutton.component';
import { ListSelectComponent } from '../../api/elements/listselect.component';


export class L0001BranchModel extends ViewModel {
    btnCancel: ActionButtonComponent;
    btnOk: ActionButtonComponent;
    lseBranches: ListSelectComponent;

    constructor() {
        super();
    }
}
