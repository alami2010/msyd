import { ViewModel } from '../../api/model/view.model';
import { NavigationTreeViewComponent } from '../../api/navigation/navigationtreeview.component';

export class L0004LicencesModel extends ViewModel {
    navigationTree: NavigationTreeViewComponent;
}
