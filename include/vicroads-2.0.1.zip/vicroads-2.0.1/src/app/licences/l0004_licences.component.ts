import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ViewCommon } from '../api/service/viewcommon.service';
import { CLIENT_SERVICE_PROVIDER, LicencesService } from './services/licences.service';
import { StateService } from 'ui-router-ng2/ng2';
import { EventsCommon } from '../api/service/eventcommon.service';
import { L0004LicencesModel } from './model/l0004_licences.model';
import { BranchService } from './services/branch.service';
import { ClientFindService } from './client/search/services/clientfind.service';
import { AppState } from '../app.service';

@Component({
    selector: 'l0004-selector',
    providers: [ ViewCommon, CLIENT_SERVICE_PROVIDER, BranchService, ClientFindService ],
    templateUrl: './l0004_licences.template.html',
})
export class L0004LicencesComponent extends L0004LicencesModel implements OnInit {

    constructor(private viewCommon: ViewCommon,
                private licencesService: LicencesService,
                private eventCommon: EventsCommon,
                private route: ActivatedRoute,
                private router: Router,
                private appState: AppState,
                private branchService: BranchService) {
        super();
        this.id = 'L0004';
        this.viewCommon.registerComponent(this);
    }

    ngOnInit() {
        this.route.data.forEach((data: {res: any}) => {
            if (data.res.hasBranch) {
                if (!this.navigationTree.treeNodes) {
                    let rootPath: string[] = this.router.url.split('/');
                    console.log('Navigation Tree View reloading tree', rootPath);
                    this.navigationTree.treeNodes =
                        this.licencesService.buildTreeView(rootPath);
                    this.licencesService.selectClientSearch(this, null);
                }
            }
        });
        // This should be on the tree view?
        this.eventCommon.on(EventsCommon.UPDATE_NAVIGATION_TREE, cmd => {
            if (cmd === 'enable-all') {
                this.licencesService.enablesAllNode(this);
            } else if (cmd === 'select-search') {
                this.licencesService.selectNavigationFind(this);
            } else {
                this.licencesService.selectNavigationFind(this, cmd);
            }
        });

        this.licencesService.menuBehavior();

    }

}
