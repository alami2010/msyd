import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { L0006PersonComponent } from './search/l0006_person.component';
import { L0008MaintainComponent } from './l0008_maintain.component';
import { L0005IdentityComponent } from './search/l0005_identity.component';
import { L0007OrganizationComponent } from './search/l0007_organization.component';
import { IdentityService } from './search/identity/services/identity.service';
import { ClientFindService } from './search/services/clientfind.service';
import { AutoCompleteModule } from '../../api/elements/autocomplete/autocomplete.component';
import { FocusDirectiveModule } from '../../api/elements/focus.directive';
import { ComboBoxModule } from '../../api/elements/combobox.component';
import { CheckBoxModule } from '../../api/elements/checkbox.component';
import { RnlRadioListModule } from '../../api/elements/radiolist.component';
import { DataGridModule } from '../../api/elements/datagrid.component';
import { ActionButtonModule } from '../../api/elements/actionbutton.component';
import { TabModule } from '../../api/elements/tab.component';
import { TabService } from '../../api/elements/service/tabs.service';
import { LoggingService } from '../../api/service/logging.service';
import { NodeService } from '../../api/navigation/services/node.service';
import { T0009TradingPerson } from './search/identity/t0009_tradingperson.component';
import { MaskSelectorModule } from '../../api/elements/mask-input.directive';
import { TitleBlockModule } from '../../api/elements/titleblock.component';
import { RnlDatePickerModule } from '../../api/elements/datepicker.component';
import { TextBoxModule } from '../../api/elements/textbox.component';
import { ValidationService } from '../../api/elements/service/validation.service';
import { DomHandler } from '../../api/service/domhandler.service';
import { T0010TradingIdentity } from './search/identity/t0010_tradingidentity.component';
import { T0011TradingDriver } from './search/identity/t0011_tradingdriver.component';
import { NavigationTreeViewModule } from '../../api/navigation/navigationtreeview.component';
import { CheckboxListModule } from '../../api/elements/chekcboxlist.component';
import { IdentityResolver } from './search/services/identity.resolver.service';
import { T0012AliasName } from './search/identity/t0012_aliasname.component';
import { D0013Group } from './search/identity/detail/d0013_group.component';
import { D0014Demerit } from './search/identity/detail/d0014_demerit.component';
import { D0015DemeritWelcome } from './search/identity/detail/d0015_demerithome.component';
import { L0001BranchComponent } from '../l0001_branch.component';
import { ListSelectModule } from '../../api/elements/listselect.component';
import { BranchService } from '../services/branch.service';
import { BranchResolver } from '../services/branch.resolver.service';
import { AuthGard } from '../../api/service/authgard.service';

console.log('`Licences: Client` bundle loaded asynchronously');

// async components must be named routes for WebpackAsyncRoute
export const routes: Routes = [
    {
        path: '',
        component: L0001BranchComponent,
        canActivate: [ AuthGard ],
        resolve: {res: BranchResolver}
    },
    {
        path: 'l0001branch',
        component: L0001BranchComponent,
        canActivate: [ AuthGard ],
        resolve: {res: BranchResolver}
    },
    {
        path: 'l0006person',
        canActivate: [ AuthGard ],
        component: L0006PersonComponent
    },
    {
        path: 'l0008maintain',
        canActivate: [ AuthGard ],
        component: L0008MaintainComponent
    },
    {
        path: 'l0005identity',
        component: L0005IdentityComponent,
        canActivate: [ AuthGard ],
        resolve: {res: IdentityResolver},
        children: [
            {path: '', component: T0009TradingPerson, canActivate: [ AuthGard ]},
            {path: 't0009tradingperson', component: T0009TradingPerson, canActivate: [ AuthGard ]},
            {
                path: 't0010tradingidentity',
                component: T0010TradingIdentity,
                canActivate: [ AuthGard ],
                children: [
                    {path: '', component: D0015DemeritWelcome, canActivate: [ AuthGard ]},
                    {path: 'd0013group', component: D0013Group, canActivate: [ AuthGard ]},
                    {
                        path: 'd0014demerit/:dpointId',
                        component: D0014Demerit,
                        canActivate: [ AuthGard ]
                    }
                ]
            },
            {path: 't0011tradingdriver', component: T0011TradingDriver, canActivate: [ AuthGard ]},
            {path: 't0012aliasname', component: T0012AliasName, canActivate: [ AuthGard ]}
        ]
    },
    {
        path: 'l0007organization',
        component: L0007OrganizationComponent,
        canActivate: [ AuthGard ]
    }
];

@NgModule({
    declarations: [
        // Components / Directives/ Pipes
        L0006PersonComponent,
        L0008MaintainComponent,
        L0005IdentityComponent,
        L0007OrganizationComponent,
        T0009TradingPerson,
        T0010TradingIdentity,
        T0011TradingDriver,
        T0012AliasName,
        D0015DemeritWelcome,
        D0013Group,
        D0014Demerit,
        L0001BranchComponent
        // API Components... Maybe should be converter to modules?
    ],
    imports: [
        CommonModule,
        FormsModule,
        RouterModule.forChild(routes),
        AutoCompleteModule,
        FocusDirectiveModule,
        ComboBoxModule,
        CheckBoxModule,
        CheckboxListModule,
        RnlRadioListModule,
        DataGridModule,
        ActionButtonModule,
        TabModule,
        MaskSelectorModule,
        TitleBlockModule,
        RnlDatePickerModule,
        TextBoxModule,
        NavigationTreeViewModule,
        ListSelectModule
    ],
    providers: [
        IdentityService,
        TabService,
        ClientFindService,
        LoggingService,
        NodeService,
        ValidationService,
        DomHandler,
        IdentityResolver,
        BranchService,
        BranchResolver
    ]
})
export default class ClientModule {
    static routes = routes;
}
