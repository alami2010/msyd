import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ViewCommon } from '../../../api/service/viewcommon.service';
import { L0005IdentityModel } from './model/l0005_identity.model';
import { IdentityService, PERSON_SERVICE_PROVIDER } from './services/identity.service';
import { ToasterService } from '../../../api/toaster/toaster.service';
import { LoggingService } from '../../../api/service/logging.service';

@Component({
    selector: 'l0005-selector',
    templateUrl: './l0005_identity.template.html',
    providers: [PERSON_SERVICE_PROVIDER]
})
export class L0005IdentityComponent extends L0005IdentityModel implements OnInit {

    constructor(private viewCommon: ViewCommon,
                private route: ActivatedRoute,
                private log: LoggingService,
                private identityService: IdentityService) {
        super();
        this.id = 'L0005';
        this.viewCommon.registerComponent(this);
    }

    ngOnInit() {
        this.identityService.loadTreeView(this);
    }

    formatDate(e: any) {
        console.log('Date selected', e);
    }

}
