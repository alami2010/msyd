import {Injectable} from "@angular/core";
import {T0011TradingDriver} from "../t0011_tradingdriver.component";
import {T0011TradingDriverModel} from "../model/t0011_tradingdriver.model";


@Injectable()
export class DriverService {

  initialize(view: T0011TradingDriverModel) {
    view.rdlDriverType.list.push({key:1, value:'2 wheel'});
    view.rdlDriverType.list.push({key:2, value:'4 wheel'});
    view.rdlDriverType.list.push({key:3, value:'8 wheel'});

    view.rdlMaleFemal.list.push({key:'M', value:'Male'});
    view.rdlMaleFemal.list.push({key:'F', value:'Female'});

    view.driverType = 1;
    view.licenceValid = true;
    view.ckcValidBound.value = true;
    view.otherValue = true;
    view.rdlMaleFemal.value = '';

    view.ckcListDays.list.push({key:'MO', value:'Monday'});
    view.ckcListDays.list.push({key:'TU', value:'Tuesday'});
    view.ckcListDays.list.push({key:'WE', value:'Wednesday'});
    view.ckcListDays.list.push({key:'TH', value:'Thursday'});
    view.ckcListDays.list.push({key:'FR', value:'Friday'});
    view.ckcListDays.list.push({key:'SA', value:'Saturday'});
    view.ckcListDays.list.push({key:'SU', value:'Sunday'});

    view.cklSemesters.list.push({key:1, value:'First'});
    view.cklSemesters.list.push({key:2, value:'Second'});

    view.selectedSemesters = [];
    view.selectedSemesters.push({key:1, value:'First'});
  }
}
