import { Component } from '@angular/core';
import { ViewModel } from '../../../../../api/model/view.model';
import { ViewCommon } from '../../../../../api/service/viewcommon.service';

@Component({
    selector: 'd0015-selector',
    template: '<h3>Demerit welcome</h3>'
})
export class D0015DemeritWelcome extends ViewModel {

    constructor(viewCommon: ViewCommon) {
        super();
        this.id = 'D0015';
        viewCommon.registerComponent(this);
    }
}
