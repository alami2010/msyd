import { ViewModel } from '../../../../../api/model/view.model';
import { NavigationTreeViewComponent } from '../../../../../api/navigation/navigationtreeview.component';
import { RnlDatePickerComponent } from '../../../../../api/elements/datepicker.component';
import { TextBoxComponent } from '../../../../../api/elements/textbox.component';
import { ButtonElement } from '../../../../../api/model/button.element';
import { ComboBoxComponent } from '../../../../../api/elements/combobox.component';
import { ViewListValidation } from '../../../../../api/model/viewlistvalidation.element';
import { KeyValueModel } from '../../../../../api/model/keyvalue.model';
import { CheckBoxComponent } from '../../../../../api/elements/checkbox.component';

export class T0009TradingPersonModel extends ViewModel {
    dt: Date;
    boundDate: string;
    ntvDemeritPoints: NavigationTreeViewComponent;
    dtpReceived: RnlDatePickerComponent;
    dtpTest: RnlDatePickerComponent;
    ckcDtpReceived: CheckBoxComponent;

    btnBatchVal: ButtonElement;

    tbxRnlTwo: TextBoxComponent;
    tbxInputReq: TextBoxComponent;
    tbxUserAgeLt: TextBoxComponent;
    tbxUserAgeGt: TextBoxComponent;
    tbxEmail: TextBoxComponent;

    cbxRequired: ViewListValidation;

    dateFormat: Date;
    currencyFormat: number;
    numberFormat: number;
    cbxSelectOption: ComboBoxComponent;
    dateString: string;
    cbxSelectOptionValue: KeyValueModel;
    selectOption: string;
    optionRequired: string;
    enableSelectOption: boolean;
}
