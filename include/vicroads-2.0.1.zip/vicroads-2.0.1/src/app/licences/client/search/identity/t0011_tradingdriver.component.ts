import { Component } from '@angular/core';
import { ViewCommon } from '../../../../api/service/viewcommon.service';
import { T0011TradingDriverModel } from './model/t0011_tradingdriver.model';
import { DriverService } from './services/driver.service';
import { LoggingService } from '../../../../api/service/logging.service';
import { KeyValueModel } from '../../../../api/model/keyvalue.model';

@Component({
    selector: 't0010-trading-identity',
    templateUrl: './t0011_tradingidriver.template.html',
    providers: [ DriverService ]
})
export class T0011TradingDriver extends T0011TradingDriverModel {

    constructor(viewCommon: ViewCommon,
                private driverService: DriverService,
                private log: LoggingService) {
        super();
        this.id = 'T0011';
        viewCommon.registerComponent(this);
    }

    ngOnInit() {
        this.driverService.initialize(this);
    }

    genderChange(e: KeyValueModel) {
        this.log.debug('Gender change', e);
        this.maleFemal = e.key;
    }

    checkBoxChange(e: any) {
        this.otherValue = e;
    }

    dayChange(e: any) {
        this.daysOfWeek = e;
    }
}
