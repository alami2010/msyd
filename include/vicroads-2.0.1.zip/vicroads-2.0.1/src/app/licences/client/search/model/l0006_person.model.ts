import { ViewModel } from '../../../../api/model/view.model';
import { ActionButtonComponent } from '../../../../api/elements/actionbutton.component';
import { DataGridComponent } from '../../../../api/elements/datagrid.component';

/**
 * VOD PersonModel extending ViewModel
 */
export class L0006PersonModel extends ViewModel {
    btnOpen: ActionButtonComponent;
    btnNew: ActionButtonComponent;
    btnFind: ActionButtonComponent;
    dtgPerson: DataGridComponent;
}
