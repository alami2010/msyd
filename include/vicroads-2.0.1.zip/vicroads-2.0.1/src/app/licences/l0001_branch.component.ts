import { Component, OnInit } from '@angular/core';
import { ViewCommon } from '../api/service/viewcommon.service';
import { L0001BranchModel } from './model/l0001_branch.model';
import { BranchService } from './services/branch.service';
import { PluginService } from '../api/plugins/plugin.service';
import { DataStoreService } from '../api/service/datastore.service';
import { ActivatedRoute, Router } from '@angular/router';
import { KeyValueModel } from '../api/model/keyvalue.model';

declare var $: any;
declare var jQuery: any;

@Component({
    selector: 'L0001',
    templateUrl: './l0001_branch.template.html'
})
export class L0001BranchComponent extends L0001BranchModel implements OnInit {

    visible: boolean;

    constructor(private viewCommon: ViewCommon,
                private branchService: BranchService,
                private pluginService: PluginService,
                private ds: DataStoreService,
                private route: ActivatedRoute,
                private router: Router) {
        super();
        this.id = 'L0001';
        this.viewCommon.registerComponent(this);
    }

    ngOnInit() {
        console.log('hello `L0001BranchComponent` component');
        this.pluginService.collaspeTreeViewMenuInView();

        this.btnCancel.value = 'Cancel';
        this.btnCancel.default = true;
        this.btnOk.value = 'OK';

        this.btnOk.primary = true;
        // Test on emitting event...
        this.btnCancel.clickEvent.emit({});
        this.visible = true;
        this.lseBranches.size = 10;

        this.lseBranches.focused = true;

        this.route.data.forEach((data: { res: KeyValueModel[]}) => {
            this.lseBranches.list = data.res;
        });

        // this.branchService.loadBranchOffices(this.lseBranches);
    }

    branchSelection() {
        this.branchService.loadBranch(this.lseBranches);
        let clientID: string = '0';
        if (this.ds.client && this.ds.client.id) {
            clientID = this.ds.client.id;
        }
        this.ds.branch.id = this.lseBranches.value;
        // TODO: revision v2
        // this.state.go('a0001_licences.l0004_licences.l0006_person', {
        //     branchID: this.lseBranches.value,
        //     clientID: clientID
        // });
        this.router.navigate(['l0004licences', this.ds.branch.id, clientID, 'l0006person']);
    }

    back() {
    }

}
