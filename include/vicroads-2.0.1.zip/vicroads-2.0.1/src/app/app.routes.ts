import { Routes, RouterModule } from '@angular/router';

import { L0010MessagesComponent } from './message/l0010_message.component';
import { MessageResolver } from './message/services/message.resolver.service';
import { L0004LicencesComponent } from './licences/l0004_licences.component';
import { LicencesResolver } from './licences/services/licences.resolver.service';
import { L0009LoginComponent } from './login/l0009_login.component';
import { AuthGard } from './api/service/authgard.service';

export const ROUTES: Routes = [
    {
        path: '',
        component: L0010MessagesComponent,
        canActivate: [ AuthGard ],
        resolve: {res: MessageResolver}
    },
    {
        path: 'l0010messages',
        component: L0010MessagesComponent,
        canActivate: [ AuthGard ],
        resolve: {res: MessageResolver}
    },
    {
        path: 'l0004licences/:branchId/:clientId',
        resolve: {res: LicencesResolver},
        canActivate: [ AuthGard ],
        component: L0004LicencesComponent, loadChildren: () => System.import('./licences/client')
    },
    {
        path: 'l0004licences',
        resolve: {res: LicencesResolver},
        canActivate: [ AuthGard ],
        component: L0004LicencesComponent, loadChildren: () => System.import('./licences/client')
    },
    {
        path: 'l0009login', component: L0009LoginComponent
    },
    {
        path: 'l0009login/:returnUrl', component: L0009LoginComponent
    }
];
