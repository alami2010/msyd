
export class MessageModel {
  head: string;
  desc: string;
}
