import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs';
import { MessageModel } from '../model/message.model';
import { AsyncRequest } from '../../api/model/security/asyncrequest.model';

@Injectable()
export class MessageService {
    /**
     *
     */
    public constructor(private http: Http) {
    }

    /**
     * Back end calls update
     */
    public allMessages(request: AsyncRequest<any>): Observable<MessageModel[]> {
        let headers = new Headers({'Content-Type': 'application/json'});
        let options = new RequestOptions({headers: headers});
        // noinspection TypeScriptUnresolvedFunction
        return this.http.post('/api/secure/allmessages', JSON.stringify(request), options)
            .map(res => res['data']);
    }
}
