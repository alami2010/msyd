import {
    Http,
    RequestOptions,
    ConnectionBackend,
    RequestOptionsArgs,
    ResponseOptions,
    Response
} from '@angular/http';
import { Router, ActivatedRoute } from '@angular/router';
import { Injectable } from '@angular/core';
import { EventsCommon } from './eventcommon.service';
import { Observable } from 'rxjs';
import { SeverityType } from '../model/security/asyncmessage.model';
import { DataStoreService } from './datastore.service';
import { UserModel } from '../model/security/user.model';


@Injectable()
export class AuthHttpService extends Http {

    public returnPath: string;
    public returnParams: any;
    private LOGIN_PAGE: string = 'l0009login';
    private token: string;

    constructor(backend: ConnectionBackend,
                defaultOptions: RequestOptions,
                private eventsCommon: EventsCommon,
                private router: Router,
                private route: ActivatedRoute,
                private dataStore: DataStoreService) {
        super(backend, defaultOptions);

        this.token = '';

        eventsCommon.on(EventsCommon.AUTH_SUCCESS, data => {
            console.log('Updating token', data);
            this.token = data;
        });

        eventsCommon.on(EventsCommon.AUTH_LOGOUT, data => {
            console.log('Loggin out...');
            this.token = '';
        });

        console.log('Building AuthHttpService...');

    }

    /**
     * Performs a request with `get` http method.
     * @param url
     * @param options
     * @returns {Observable<R>}
     */
    get(url: string, options?: RequestOptionsArgs): Observable<Response> {
        // Prevent basic auth.
        options.headers.append('X-Requested-With', 'XMLHttpRequest');
        // noinspection TypeScriptUnresolvedFunction
        return super.get(url, options)
            .map(res => res.json())
            .map(res => {
                if (res.messages) {
                    for (let m of res.messages) {
                        if (m.severity === SeverityType.ERROR) {
                            this.eventsCommon.broadcast(EventsCommon.POP_ERROR,
                                {title: m.code, message: m.description});
                        } else if (m.severity === SeverityType.SUCCESS) {
                            this.eventsCommon.broadcast(EventsCommon.POP_SUCCESS,
                                {title: m.code, message: m.description});
                        }
                    }
                }
                return res.data;
            }).catch((error: any): Observable<Response> =>
                this.errorDisplayAndRedirect(error, false));
    }

    /**
     * Performs a request with `post` http method.
     * @param url
     * @param body
     * @param options
     * @returns {Observable<R>}
     */
    post(url: string, body: any, options?: RequestOptionsArgs): Observable<Response> {
        // Prevent basic auth.
        let isCheckingGuard = false;
        options.headers.append('X-Requested-With', 'XMLHttpRequest');
        if (options.headers.get('x-option-guard') === 'true') {
            isCheckingGuard = true;
        }
        // Check user authenticated.
        console.log('Auth User found....', this.dataStore.user.name);
        if (typeof this.dataStore.user.name === 'undefined'
            && this.router.url.indexOf('l0009login') === -1) {
            // User needs to log.
            this.dataStore.user = new UserModel(this.dataStore.user.roles,
                this.dataStore.user.name,
                window.location.hash.substring(1));
            console.log('Setting up login return url', this.dataStore.user);
            this.router.navigate([ this.LOGIN_PAGE, btoa( window.location.hash.substring(1) ) ]);
            let fakeResponse: Response = new Response(new ResponseOptions({body: '{}', url}));
            // noinspection TypeScriptUnresolvedFunction
            return Observable.of(fakeResponse);
        } else if (typeof this.dataStore.user.name === 'undefined') {
            // First auth we do not want the XSRF cookie.
            // document.cookie = null;
        }
        // noinspection TypeScriptUnresolvedFunction
        return super.post(url, body, options).map(r => r.json())
            .do(res => {
                // let res = r.json();
                if (res.messages) {
                    for (let m of res.messages) {
                        if (m.severity === SeverityType.ERROR) {
                            this.eventsCommon.broadcast(EventsCommon.POP_ERROR,
                                {title: m.code, message: m.description});
                        } else if (m.severity === SeverityType.SUCCESS) {
                            this.eventsCommon.broadcast(EventsCommon.POP_SUCCESS,
                                {title: m.code, message: m.description});
                        }
                    }
                }
                return res.data;
            }).catch((error: any): Observable<Response> =>
                this.errorDisplayAndRedirect(error, isCheckingGuard));
    }

    /**
     * Displays an UI error messages and redirect to login page.
     * @param error
     * @param isCheckingGuard
     * @return {ErrorObservable}
     */
    private errorDisplayAndRedirect(error: any, isCheckingGuard: boolean): Observable<Response> {
        let err: any = error._body ? JSON.parse(error._body) : null;
        let errMsg = 'unexpected error';
        let titleMsg = 'Error';
        let suffix = '. You do not have access to this view. Please contact your I.T. team.';
        if (err) {
            if (err.message) {
                titleMsg = err.status + ' - Error';
                errMsg = err.message + (isCheckingGuard ? suffix : '');
            } else if (err.status === 401) {
                titleMsg = '401 - Unauthorized';
                errMsg = 'Authentication error' + (isCheckingGuard ? suffix : '');
            } else if (err.status === 403) {
                titleMsg = '403 - Unauthorized';
                errMsg = 'Authorization error' + (isCheckingGuard ? suffix : '');
            }
        } else {
            titleMsg = error.status + ' Error';
            errMsg = error.statusText + (isCheckingGuard ? suffix : '');
        }
        // Call popup error feedback
        this.eventsCommon.broadcast(EventsCommon.POP_ERROR, {
            title: titleMsg,
            message: errMsg
        });
        // Manage redirection?
        if (!isCheckingGuard) {
            this.router.navigate([ this.LOGIN_PAGE ]);
        }

        return Observable.throw(errMsg);
    }
}
