import { Injectable } from '@angular/core';
import { Subject, Observable } from 'rxjs';

@Injectable()
export class EventsCommon {
    static UPDATE_BRANCH = 'update-branch';
    static UPDATE_VIEW_ID = 'update-view-id';
    static UPDATE_NAVIGATION_TREE = 'update-navigation-tree';
    static UPDATE_CLIENT = 'update-client';
    static UPDATE_LOGIN = 'update-login';
    static UPDATE_USER = 'update-user';
    static POP_ERROR = 'pop-error';
    static POP_SUCCESS = 'pop-success';
    static AUTH_SUCCESS = 'auth-success';
    static AUTH_LOGOUT = 'auth-logout';
    listeners: any;
    eventsSubject: any;
    events: any;

    constructor() {
        this.listeners = {};
        this.eventsSubject = new Subject<any>();
        // noinspection TypeScriptUnresolvedFunction
        this.events = Observable.from(this.eventsSubject);

        this.events.subscribe(
            ({name, args}) => {
                if (this.listeners[ name ]) {
                    for (let listener of this.listeners[ name ]) {
                        listener(...args);
                    }
                }
            });
    }

    on(name, listener) {
        if (!this.listeners[ name ]) {
            this.listeners[ name ] = [];
        }
        this.listeners[ name ].push(listener);
    }

    broadcast(name, ...args) {
        this.eventsSubject.next({
            name,
            args
        });
    }
}
