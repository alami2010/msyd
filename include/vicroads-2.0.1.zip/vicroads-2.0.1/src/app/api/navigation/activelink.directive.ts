import {
    Directive, Input, ElementRef, HostListener,
    EventEmitter, Output, Renderer, NgModule
} from '@angular/core';
import { LoggingService } from '../service/logging.service';
import { Router, ActivatedRoute } from '@angular/router';
import set = Reflect.set;
import { NodeModel } from './model/node.model';
import { DomHandler } from '../service/domhandler.service';
import { NodeService } from './services/node.service';

@Directive({
    selector: '[rnl-active-link],[rnl-active-param],[node]'
})
export class ActiveLinkDirective {
    private static previous: ActiveLinkDirective[] = [];

    @Input('rnl-active-link')
    activeLink: string;
    @Input('rnl-active-param')
    activeParam: any;
    @Input()
    node: NodeModel;
    _onStateEnter: any;
    _onStateExit: any;
    element: HTMLElement;

    private routePath: string[];
    private active: boolean;

    constructor(private router: Router,
                private route: ActivatedRoute,
                private el: ElementRef,
                private log: LoggingService,
                private domHandler: DomHandler,
                private nodeService: NodeService,
                rnd: Renderer) {
        this.element = this.el.nativeElement;
        ActiveLinkDirective.previous.push(this);
    }

    /**
     * Click on a link, activate link and perform navigation.
     * Prevent the user from clicking multiple times
     * if the link is active.
     * @param e
     */
    @HostListener('click', [ '$event' ])
    onClickEvent(e: Event) {
        if (this.activeParam && this.activeLink) {
            this.router.navigate([ this.activeLink, this.activeParam ],
                {relativeTo: this.route});
        } else if (this.activeLink) {
            this.router.navigate([ this.activeLink ],
                {relativeTo: this.route});
        }

        if (this.activeLink && this.activeLink !== '') {
            this.nodeService.activateNode(this.node);
            // this.setInnactive();
            // this.setActive();
        }
    }

    ngOnInit() {
        this.routePath = [];
        let routes: string[] = this.router.url.split('/');
        for (let segment of routes) {
            let last = this.routePath.length - routes.length;
            if (this.activeLink === segment && !this.activeParam) {
                this.setActive();
            } else if (this.activeParam === segment) {
                this.setActive();
            }
            if (segment !== '' && last !== -2) { // Count first '/'
                this.routePath.push(segment);
            }
        }
    }

    ngOnDestroy() {
        this.log.debug('Destroy');
        let idx: number = ActiveLinkDirective.previous.indexOf(this);
        ActiveLinkDirective.previous.splice(idx, 1);
    }

    public setInnactive() {
        // let root = this.domHandler.getFurthest(this.el.nativeElement, 'navigation-tree');
        // let removable = this.domHandler.find(root, 'span');
        // // Bug IE11, forEach not supported.
        // for (let s of removable) {
        //     if (s.classList.contains('active')) {
        //         s.classList.remove('active');
        //     }
        // }
        // Get parent
        let parent = this.node.parent;
        while (parent !== null && parent.parent !== null) {
            parent = parent.parent;
        }
        this.nodeService.traverseTreeAndSetProperty([], parent.children, '_active', false, false);
        console.log('Set innactive', parent);
        // removable.forEach(s => {
        //
        // });
        // ActiveLinkDirective.previous.forEach(a => {
        //     a.element.parentElement.classList.remove('active');
        // });
    }

    private setActive(): boolean {
        console.log('Set active!');
        // if (!this.element.parentElement.classList.contains('active')) {
        //     this.element.parentElement.classList.add('active');
        //     return true;
        // }
        this.node._active = true;
        return false;
    }

}

@NgModule({
    declarations: [ ActiveLinkDirective ],
    exports: [ ActiveLinkDirective ]
})
export class ActiveLinkModule {
}
