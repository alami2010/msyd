import { Component, Input, NgModule } from '@angular/core';

@Component({
    selector: 'rnl-block-title',
    template: `
    <div [attr.class]="classes"><h3 class="rd_line"><span>{{title}}</span></h3></div>
  `
})
export class TitleBlockComponent {
    @Input()
    title: string;
    @Input()
    col: number;
    classes: string;

    constructor() {

    }

    ngOnInit() {
        if (this.col) {
            this.classes = 'col-md-' + String(this.col);
        } else {
            this.classes = 'col-md-4';
        }
    }
}

@NgModule({
    declarations: [TitleBlockComponent],
    exports: [ TitleBlockComponent]
})
export class TitleBlockModule {}
