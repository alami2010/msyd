import { Directive, ElementRef, HostListener } from '@angular/core';
@Directive({
    selector: 'a[uiSref]'
})
export class LinkDirective {
    constructor(private el: ElementRef) {
    }

    @HostListener('click', [ '$event' ]) onClick(e: any) {
        let htmlElement: HTMLElement = this.el.nativeElement;
        let classList: DOMTokenList = htmlElement.classList;

        if (classList.contains('active')) {
            e.cancelBubble = true;
            htmlElement.removeAttribute('disabled');
            return true;
        } else {
            htmlElement.setAttribute('disabled', 'disabled');
            console.log('Click on acitve link.');
            e.cancelBubble = true;
            e.preventDefault();
            return false;
        }

    }
}
