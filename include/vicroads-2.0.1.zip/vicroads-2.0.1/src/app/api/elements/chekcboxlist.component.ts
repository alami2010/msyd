import {
    Component,
    ElementRef,
    EventEmitter,
    Input,
    forwardRef,
    NgModule,
    Output
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { ViewListElement } from '../model/viewlist.element';
import { ViewCommon } from '../service/viewcommon.service';
import { LoggingService } from '../service/logging.service';
import { KeyValueModel } from '../model/keyvalue.model';
import { NG_VALUE_ACCESSOR } from '@angular/forms';

export const CKC_VALUE_ACCESSOR: any = {
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => CheckboxListComponent),
    multi: true
};

@Component({
    selector: 'rnl-check-box-list',
    template: `
    <span *ngIf="!horizontal">
    <div class="checkbox" *ngFor="let item of list; let i = index">
      <label><input type="checkbox"
                    [attr.id]="listId[i]"
                    [attr.name]="'cklName'+id"
                    [checked]="value[i] === item.key"
                    (change)="checkBoxChange($event, item)"
      >{{item.value}}</label>
    </div>
    </span>
    <span *ngIf="horizontal">
      <label class="checkbox-inline" *ngFor="let item of list; let i = index"><input type="checkbox"
                    [attr.id]="listId[i]"
                    [attr.name]="'cklName'+id"
                    [checked]="value[i] === item.key"
                    (change)="checkBoxChange($event, item)"
      >{{item.value}}</label>
    </span>
  `,
    providers: [ CKC_VALUE_ACCESSOR ]
})
export class CheckboxListComponent extends ViewListElement {

    @Input()
    listId: string[];
    @Input()
    list: KeyValueModel[];
    @Output()
    checkBoxSelect: EventEmitter<KeyValueModel[]> = new EventEmitter<KeyValueModel[]>(false);
    @Input()
    horizontal: boolean = false;
    @Input()
    value: any;

    onModelChange: Function = (value: any) => {
    };
    onModelTouched: Function = () => {
    };

    constructor(private el: ElementRef,
                private  viewCommon: ViewCommon,
                private log: LoggingService) {
        super();
        this.listId = [];
        if (!this.list) {
            this.list = [];
        }
        if (!this.value) {
            this.value = {};
        }
        this.id = this.el.nativeElement.id;
        this.viewCommon.registerComponentElement(this);
        this.value = [];
    }

    ngOnInit() {
        this.list.forEach((v: KeyValueModel, i: number) => {
            this.listId.push(this.id + String(v.key));
        });

        if (this.horizontal) {

        }
    }

    checkBoxChange(e: any, item: KeyValueModel) {
        this.log.debug('Checkbox clicked', item);
        let el: HTMLInputElement = e.srcElement || e.target; // Fix for FireFox.
        if (el.checked) {
            this.value.push(item);
        } else {
            this.value.splice(this.value.indexOf(item), 1);
        }
        this.checkBoxSelect.emit(this.value);
        this.onModelChange(this.value);
    }

    writeValue(value: any): void {
        if (value) this.value = value;
    }

    registerOnChange(fn: Function): void {
        this.onModelChange = fn;
    }

    registerOnTouched(fn: Function): void {
        this.onModelTouched = fn;
    }
}

@NgModule({
    declarations: [ CheckboxListComponent ],
    exports: [ CheckboxListComponent ],
    imports: [ CommonModule ]
})
export class CheckboxListModule {
}
