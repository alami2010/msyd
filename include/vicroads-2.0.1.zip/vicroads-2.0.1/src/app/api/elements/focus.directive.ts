import { Directive, Input, ElementRef, SimpleChange, OnChanges, NgModule } from '@angular/core';


class SimpleChanges {
    [key: string]: SimpleChange;
}

@Directive({
    selector: '[rnl-focused]',
    providers: []
})
export class FocusDirective implements OnChanges {
    changedValue: boolean;

    @Input('rnl-focused')
    focused: boolean;

    constructor(private el: ElementRef) {

    }

    /**
     * Detect changes in the directive.
     * @param change contains the change map.
     */
    ngOnChanges(change: SimpleChanges) {
        if (change[ 'focused' ]) {
            if (change[ 'focused' ].currentValue) setTimeout(() => {
                this.el.nativeElement.focus();
            }, 0);
        }
    }
}

@NgModule({
    exports: [FocusDirective],
    declarations: [FocusDirective]
})
export class FocusDirectiveModule {}
