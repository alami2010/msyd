import { Injectable } from '@angular/core';
import { TabItem } from '../../model/tablist.model';
import { LoggingService } from '../../service/logging.service';

@Injectable()
export class TabService {

    tabFound: TabItem;

    constructor(private log: LoggingService) {

    }

    /**
     * Add a tab, the parent must always be present.
     * @param label not null
     * @param uiLink
     * @param inlineHelp
     * @param parent not null
     * @returns {TabItem}
     */
    public addTab(label: string, uiLink: string, inlineHelp: string, parent: TabItem): TabItem {
        if (!label) {
            throw('Cannot add tab, the label cannot be null or undefined.');
        }
        if (!parent) {
            throw('Cannot add tab, the parent cannot be null or undefined.');
        }
        let tab: TabItem = new TabItem();
        tab.parent = parent;
        if (!parent.children) parent.children = [];
        tab.active = false;
        tab.enabled = true;
        tab.text = label;
        tab.uiLink = uiLink;
        tab.inlineHelp = inlineHelp;
        tab.visible = true;
        parent.children.push(tab);
        return tab;
    }

    /**
     * Select tab into view from the state _name.
     * @param tabItems
     * @param state
     * @return true if the tab is found in the router urls.
     */
    public selectTabInView(tabItems: TabItem[], state: String): TabItem {
        this.log.debug('Selecting tab into view', state);
        if (state) {
            let states: string[] = state.split('/');
            // this.tabFound = null;
            let tabFound = null;
            for (let i: number = states.length - 1; i >= 0; i--) {
                tabFound = this.findRecursiveTab(tabItems, 'uiLink', states[ i ]);
                if (tabFound) break;
            }
            this.log.debug('Is tab found', tabFound);
            return tabFound;
        }
        return null;
    }

    /**
     * Find a corresponding tab with the following criteria:
     * tab's property _name and its value.
     * @param tabItems
     * @param propName
     * @param value
     * @returns {TabItem}
     */
    private findRecursiveTab(tabItems: TabItem[], propName: string, value: any): TabItem {
        let tabReturned = null;
        if (tabItems) {
            for (let i = 0; i < tabItems.length; i++) {
                if (tabItems[ i ][ propName ]) {
                    let refPropValue = tabItems[ i ][ propName ].replace('^', '');
                    this.log.debug('Find Recursive', refPropValue, i, value);
                    if (refPropValue === value) {
                        // this.tabFound = tabItems[ i ];

                        if (tabItems[ i ].parent) {
                            tabItems[ i ].parent.active = true;
                            tabItems[ i ].parent.activeStr = 'active-parent';
                        }
                        tabItems[ i ].active = true;
                        tabItems[ i ].activeStr = 'active';
                        tabReturned = tabItems[ i ];
                        break;
                    }
                }
                if (tabItems[ i ].children && tabItems[ i ].children.length > 0) {
                    return this.findRecursiveTab(tabItems[ i ].children, propName, value);
                }
            }
        }
        return tabReturned;
    }
}
