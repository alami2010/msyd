import { Injectable } from '@angular/core';
import { ValidationType } from '../../model/validation.model';
import { ViewCommon } from '../../service/viewcommon.service';
import { ViewModel } from '../../model/view.model';
import { LoggingService } from '../../service/logging.service';
import { ValidationInterface } from '../../model/validation.interface';
import { ViewValidation } from '../../model/viewvalidation.element';
import { ViewListValidation } from '../../model/viewlistvalidation.element';

@Injectable()
export class ValidationService {

    constructor(private viewCommon: ViewCommon, private log: LoggingService) {
        console.log('Building validation service');
    }


    public validate(element: ValidationInterface) {
        element.pristine = false;
        this.viewCommon.getCurrentView().pristine = false;
        // TODO: Manage change state here.
        let error: boolean = false;
        element.validation.validations.forEach(v => {
            if (v.type === ValidationType.REQUIRED) {
                if (element.value === ''
                    || (typeof element.value === 'undefined')
                    || element.value === null) {
                    v.valid = false;
                    error = true;
                } else {
                    v.valid = true;
                }
            } else if (v.type === ValidationType.REGEX) {
                if (typeof element.value !== 'undefined' && element.value !== '') {
                    this.log.debug('REGEX element.value', element.value);
                    let regex: RegExp = new RegExp(v.regex);
                    if (regex.test(String(element.value))) {
                        v.valid = true;
                    } else {
                        v.valid = false;
                        error = true;
                    }
                } else {
                    v.valid = true;
                }
            } else if (v.type === ValidationType.MAX) {
                let numValue = Number(element.value) || 0;
                if (numValue > v.range) {
                    v.valid = false;
                    error = true;
                } else {
                    v.valid = true;
                }
            } else if (v.type === ValidationType.MIN) {
                let numValue = Number(element.value) || 0;
                if (numValue < v.range) {
                    v.valid = false;
                    error = true;
                } else {
                    v.valid = true;
                }
            } else if (v.type === ValidationType.CUSTOM) {
                if (typeof v.custom !== 'undefined') {
                    let result: boolean = false;
                    result = v.custom.call(result, element.value);
                    if (result) {
                        v.valid = true;
                    } else {
                        v.valid = false;
                        error = true;
                    }
                }
            }
            // Register this validation for global check.
            this.viewCommon.addValidationError(v);
        });
        // Set error for the current control.
        element.hasError = error;
        // Set the error flag for the current view.
        this.viewCommon.checkError();
    }

    /**
     * Perform a batch validation by iterating over all member of the view.
     * Members have to inherit ViewValidation.
     */
    public viewValidation() {
        let view: ViewModel = this.viewCommon.getCurrentView();
        for (let p in view) {
            // http://stackoverflow.com/questions/14425568/interface-type-check-with-typescript
            if (view[ p ] instanceof ViewValidation || view[ p ] instanceof ViewListValidation) {
                this.validate(view[ p ] as ValidationInterface);
            }
        }
        this.viewCommon.checkError();
    }
}
