import {
    Component,
    Input,
    ElementRef,
    forwardRef,
    EventEmitter,
    Output,
    NgModule
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ViewCommon } from '../service/viewcommon.service';
import { LoggingService } from '../service/logging.service';
import { NG_VALUE_ACCESSOR, ControlValueAccessor } from '@angular/forms';
import { ViewFocusedElement } from '../model/viewfocus.element';

export const CKB_VALUE_ACCESSOR: any = {
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => CheckBoxComponent),
    multi: true
};

@Component({
    selector: 'rnl-check-box',
    template: `
    <div [attr.class]="classes" [ngClass]="{'disabled':!enabled}">
        <label [attr.class]="labelClass" [attr.for]="inputId">
          <abbr *ngIf="inlineHelp !== ''" [attr.title]="inlineHelp">{{label}}</abbr>
          <span *ngIf="inlineHelp === ''">{{label}}</span>
          <span *ngIf="required">*</span>
        </label>
        <div [attr.class]="divInputClass">
          <input [attr.id]="inputId" 
                 type="checkbox" 
                 [attr.class]="inputClass"
                 [(ngModel)]="value" 
                 [attr.title]="inlineHelp" 
                 [disabled]="!enabled"
                 (click)="changeValue($event)"
                 />
        </div>
    </div>
  `,
    providers: [ CKB_VALUE_ACCESSOR ]
})
export class CheckBoxComponent extends ViewFocusedElement implements ControlValueAccessor {

    labelClass: string;
    @Input()
    inlineHelp: string;
    inputId: string;
    inputClass: string;
    @Input()
    label: string;
    @Input()
    generalCol: number;
    divInputClass: string;

    @Output()
    checkBoxSelect: EventEmitter<boolean> = new EventEmitter<boolean>(false);

    onModelChange: Function = (value: any) => {
    };
    onModelTouched: Function = () => {
    };

    constructor(private el: ElementRef,
                private viewCommon: ViewCommon,
                private log: LoggingService) {
        super();
        this.id = el.nativeElement.id;
        this.viewCommon.registerComponentElement(this);
        this.classList.push('form-group');
        this.labelClass = 'control-label';
        if (!this.inlineHelp) this.inlineHelp = '';
        this.inputId = this.id + 'Input';
        // this.inputClass = 'form-control';
        if (!this.value) {
            this.value = false;
        }
    }

    ngOnInit() {
        this.divInputClass = '';
        this.log.debug('General col', this.generalCol);
        if (this.generalCol > 0) {
            this.labelClass += ' col-md-' + this.generalCol;
            this.divInputClass += ' col-md-' + this.generalCol;
        }
    }

    changeValue(e: any) {
        let isChecked: boolean = false;
        let el: HTMLInputElement = e.srcElement || e.target; // Fix for FireFox.
        if (el.checked) {
            isChecked = true;
        }
        this.checkBoxSelect.emit(isChecked);
        this.onModelChange(isChecked);
    }

    writeValue(value: any): void {
        if (value) this.value = value;
    }

    registerOnChange(fn: Function): void {
        this.onModelChange = fn;
    }

    registerOnTouched(fn: Function): void {
        this.onModelTouched = fn;
    }
}

@NgModule({
    imports: [ CommonModule, FormsModule ],
    exports: [ CheckBoxComponent ],
    declarations: [ CheckBoxComponent ]
})
export class CheckBoxModule {
}
