import { Component, NgModule } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { CommonModule } from '@angular/common';
import { TabElement } from '../model/tab.element';
import { Input } from '@angular/core';
import { TabItem } from '../model/tablist.model';
import { AfterViewInit } from '@angular/core';
import { ElementRef } from '@angular/core';
import { ViewCommon } from '../service/viewcommon.service';
import { StateService } from 'ui-router-ng2';
import { TabService } from './service/tabs.service';
import { LoggingService } from '../service/logging.service';
import { AppState } from '../../app.service';


@Component({
    selector: 'rnl-tab',
    templateUrl: './tab.template.html',
})
export class TabComponent extends TabElement implements AfterViewInit {
    @Input()
    tabList: TabItem[];
    children: TabItem[];
    hasSecondLvl: boolean;

    private routePath: string[];

    constructor(el: ElementRef,
                private router: Router,
                private route: ActivatedRoute,
                viewCommon: ViewCommon,
                private tabService: TabService,
                private log: LoggingService,
                private appState: AppState) {
        super();
        this.id = el.nativeElement.id;
        viewCommon.registerComponentElement(this);
        this.log.debug('Tab', this.id, 'Built');
    }

    /**
     * Initialize the tabs. If no tab is selected,
     * it will select the first tab.
     */
    ngAfterViewInit() {
        if (this.tabList) {
            let tabFound = this.tabService.selectTabInView(this.tabList, this.router.url);

            if (tabFound && tabFound.children) {
                this.children = tabFound.children;
                this.hasSecondLvl = true;
            } else if (tabFound && tabFound.parent) {
                this.children = tabFound.parent.children;
                this.hasSecondLvl = true;
            } else {
                if (this.tabList.length > 0 && this.tabList[ 0 ].children) {
                    this.tabList[ 0 ].active = true;
                    this.tabList[ 0 ].activeStr = 'active-parent';
                    this.tabList[ 0 ].children[ 0 ].active = true;
                    this.tabList[ 0 ].children[ 0 ].activeStr = 'active';
                    this.hasSecondLvl = true;
                    this.children = this.tabList[ 0 ].children;
                } else if (this.tabList.length > 0) {
                    this.tabList[ 0 ].active = true;
                    this.tabList[ 0 ].activeStr = 'active';
                }
            }
        }
    }

    /**
     * Click on a tab, perform its selection and navigate
     * to tab.uiLink if provided.
     * @param tab
     */
    selectTab(tab: TabItem) {
        // If any display the tab childers.
        if (tab.children) this.children = tab.children;
        this.log.debug('Reseting tab children', this.children);
        // Deactivate all tabs
        this.tabList.forEach(t => {
            t.active = false;
            t.activeStr = '';
            if (t.children) {
                t.children.forEach(c => {
                    c.active = false;
                    c.activeStr = '';
                });
            }
        });
        tab.active = true;
        tab.activeStr = 'active';
        // Parent activation.
        tab.parent.active = true;
        tab.parent.activeStr = 'active-parent';
        this.log.debug('Test cssClass getter', tab.cssActive);
        if (tab.uiLink) {
            this.log.info('Perform navigation', tab.uiLink);
            let slink: string = '';
            // this.buildNavigation(-2).concat(tab.uiLink)
            // this.router.navigate([ './' + tab.uiLink ]);
            this.router.navigate([ tab.uiLink ],
                {relativeTo: this.route});
        }
    }

    private buildNavigation(depth?: number): string[] {
        let depthPath = depth ? depth : -1;
        this.routePath = [];
        let routes: string[] = this.router.url.split('/');
        for (let segment of routes) {
            let last = this.routePath.length - routes.length;
            if (segment !== '' && last !== depthPath) { // Count first '/'
                this.routePath.push(segment);
            }
        }
        return this.routePath;
    }

}

@NgModule({
    imports: [ CommonModule ],
    declarations: [ TabComponent ],
    exports: [ TabComponent ]
})
export class TabModule {
}
