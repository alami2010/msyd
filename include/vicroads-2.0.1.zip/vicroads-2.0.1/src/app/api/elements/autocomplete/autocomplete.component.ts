import {
    Component,
    ElementRef,
    AfterViewInit,
    AfterViewChecked,
    DoCheck,
    Input,
    Output,
    EventEmitter,
    IterableDiffers,
    Renderer,
    forwardRef,
    IterableDiffer,
    NgModule
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { NG_VALUE_ACCESSOR, ControlValueAccessor } from '@angular/forms';
import { DomHandler } from '../../service/domhandler.service';
import { LoggingService } from '../../service/logging.service';

export const AUTOCOMPLETE_VALUE_ACCESSOR: any = {
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => AutoComplete),
    multi: true
};


const HIGHLIGHT: string = 'state-active';
const A_HIGHLIGHT: string = 'li.' + HIGHLIGHT;

@Component({
    selector: 'cautocomplete',
    templateUrl: './autocomplete.template.html',
    providers: [ AUTOCOMPLETE_VALUE_ACCESSOR ]
})
export class AutoComplete implements
    AfterViewInit, DoCheck, AfterViewChecked, ControlValueAccessor {

    @Input() minLength: number = 3;

    @Input() delay: number = 300;

    @Input() style: string;

    @Input() styleClass: string;

    @Input() inputStyle: string;

    @Input() inputStyleClass: string;

    @Input() placeholder: string;

    @Input() readonly: number;

    @Input() disabled: boolean;

    @Input() maxlength: number;

    @Input() size: number;

    @Input() suggestions: any[];

    @Output() completeMethod: EventEmitter<any> = new EventEmitter();

    @Output() onSelect: EventEmitter<any> = new EventEmitter();

    @Output() onUnselect: EventEmitter<any> = new EventEmitter();

    @Output() onDropdownClick: EventEmitter<any> = new EventEmitter();

    @Input() field: string;

    @Input() scrollHeight: string = '200px';

    @Input() dropdown: boolean;

    value: any;

    btnId: string;

    timeout: any; // Bug with TS?

    differ: IterableDiffer;

    panel: any;

    input: any;

    multipleContainer: any;

    panelVisible: boolean = false;

    documentClickListener: any;

    suggestionsUpdated: boolean;

    onModelChange: Function = (value: any) => {
    };

    onModelTouched: Function = () => {
    };

    constructor(private el: ElementRef,
                private domHandler: DomHandler,
                differs: IterableDiffers,
                private renderer: Renderer,
                private log: LoggingService) {
        this.differ = differs.find([]).create(null);
        this.btnId = this.el.nativeElement.id + 'btn';
    }

    ngDoCheck() {
        let changes = this.differ.diff(this.suggestions);

        if (changes && this.panel) {
            if (this.suggestions && this.suggestions.length) {
                this.show();
                this.suggestionsUpdated = true;
            } else {
                this.hide();
            }
        }
    }

    ngAfterViewInit() {
        this.input = this.domHandler.findSingle(this.el.nativeElement, 'input');
        this.panel = this.domHandler.findSingle(this.el.nativeElement, 'ul.dropdown-menu');
        this.documentClickListener = this.renderer.listenGlobal('body', 'click', (e) => {
            // this.log.debug('Clicking...', e);
            let element = e.srcElement;
            if (element && element.type !== 'button') {
                element = element.parentElement; // in case we click on carret.
            }
            if (element && element.id !== this.btnId) {
                this.hide();
            }
            return true;
        });
    }

    ngAfterViewChecked() {
        if (this.suggestionsUpdated) {
            this.align();
            this.suggestionsUpdated = false;
        }
    }

    writeValue(value: any): void {
        this.value = value;
    }

    registerOnChange(fn: Function): void {
        this.onModelChange = fn;
    }

    registerOnTouched(fn: Function): void {
        this.onModelTouched = fn;
    }

    onInput(event) {
        let value = event.target.value;
        if (value.length === 0) {
            this.hide();
        }

        if (value.length >= this.minLength) {
            // Cancel the search request if user types within the timeout
            if (this.timeout) {
                clearTimeout(this.timeout);
            }

            this.timeout = setTimeout(() => {
                this.search(event, value);
            }, this.delay);
        } else {
            this.log.debug('Nullifying suggestions....', this.suggestions);
            // this.suggestions = [];
        }
    }

    search(event: any, query: string) {
        // allow empty string but not undefined or null
        if (query === undefined || query === null) {
            return;
        }

        this.completeMethod.emit({
            originalEvent: event,
            query: query
        });
    }

    onItemMouseover(event) {
        if (this.disabled) {
            return;
        }

        let element = event.target;
        if (element.nodeName !== 'UL') {
            let item = this.findListItem(element);
            this.domHandler.addClass(item, HIGHLIGHT);
        }
    }

    onItemMouseout(event) {
        if (this.disabled) {
            return;
        }

        let element = event.target;
        if (element.nodeName !== 'UL') {
            let item = this.findListItem(element);
            this.domHandler.removeClass(item, HIGHLIGHT);
        }
    }

    onItemClick(event) {
        let element = event.target;
        if (element.nodeName !== 'UL') {
            let item = this.findListItem(element);
            this.selectItem(item);
        }
    }

    selectItem(item: any) {
        let itemIndex = this.domHandler.index(item);
        let selectedValue = this.suggestions[ itemIndex ];

        this.input.value = this.field ? this.resolveFieldData(selectedValue) : selectedValue;
        this.value = selectedValue;
        this.onModelChange(this.value);

        this.onSelect.emit(selectedValue);

        this.input.focus();
    }

    findListItem(element) {
        if (element.nodeName === 'A') {
            return element;
        } else {
            let parent = element.parentElement;
            while (parent.nodeName !== 'A') {
                parent = parent.parentElement;
            }
            return parent;
        }
    }

    show() {
        if (!this.panelVisible) {
            this.panelVisible = true;
            this.panel.style.zIndex = 1000; // ++PUI.zindex;
            this.domHandler.fadeIn(this.panel, 200);
        }
    }

    align() {
        this.domHandler.relPosition(this.panel, this.input);
    }

    hide() {
        this.panelVisible = false;
    }

    handleDropdownClick(event: any) {
        // this.onDropdownClick.emit({
        //   originalEvent: event,
        //   query: this.input.value
        // });
        this.log.debug('handleDropdownClick', this.panelVisible, event, this.suggestions);
        if (!this.panelVisible) {
            this.show();
            this.onDropdownClick.emit({
                originalEvent: event,
                query: ''
            });
            // select first item.
            let firstItem = this.domHandler.findSingle(this.panel, 'li:first-child');
            this.domHandler.addClass(firstItem, HIGHLIGHT);
            event.preventDefault();
            return;
        }
    }

    removeItem(item: any) {
        let itemIndex = this.domHandler.index(item);
        let removedValue = this.value.splice(itemIndex, 1)[ 0 ];
        this.onUnselect.emit(removedValue);
        this.onModelChange(this.value);
    }

    resolveFieldData(data: any): any {
        if (data && this.field) {
            if (this.field.indexOf('.') === -1) {
                return data[ this.field ];
            } else {
                let fields: string[] = this.field.split('.');
                let value = data;
                for (let i = 0, len = fields.length; i < len; ++i) {
                    value = value[ fields[ i ] ];
                }
                return value;
            }
        } else {
            return null;
        }
    }

    onKeydown(event) {
        this.log.debug('AutoComplete key down');
        // Show suggestion panel on key down.
        if (event.which === 40) {
            if (!this.panelVisible) {
                this.panelVisible = true;
                // select first item.
                let firstItem = this.domHandler.findSingle(this.panel, 'li:first-child');
                this.domHandler.addClass(firstItem, HIGHLIGHT);
                event.preventDefault();
                return;
            }
        }
        if (this.panelVisible) {
            let highlightedItem = this.domHandler.findSingle(this.panel, A_HIGHLIGHT);

            switch (event.which) {
                // down
                case 40:
                    if (highlightedItem) {
                        let nextItem = highlightedItem.nextElementSibling;
                        if (nextItem) {
                            this.domHandler.removeClass(highlightedItem, HIGHLIGHT);
                            this.domHandler.addClass(nextItem, HIGHLIGHT);
                            this.domHandler.scrollInView(this.panel, nextItem);
                        }
                    } else {
                        let firstItem = this.domHandler.findSingle(this.panel, 'li:first-child');
                        this.domHandler.addClass(firstItem, HIGHLIGHT);
                    }

                    event.preventDefault();
                    break;

                // up
                case 38:
                    if (highlightedItem) {
                        let prevItem = highlightedItem.previousElementSibling;
                        if (prevItem) {
                            this.domHandler.removeClass(highlightedItem, HIGHLIGHT);
                            this.domHandler.addClass(prevItem, HIGHLIGHT);
                            this.domHandler.scrollInView(this.panel, prevItem);
                        }
                    }

                    event.preventDefault();
                    break;

                // enter
                case 13:
                    this.selectItem(highlightedItem);
                    this.hide();
                    event.preventDefault();
                    break;

                // enter
                case 27:
                    this.hide();
                    event.preventDefault();
                    break;

                // tab
                case 9:
                    this.selectItem(highlightedItem);
                    this.hide();
                    break;
                default:
            }
        }
    }

    ngOnDestroy() {
        if (this.documentClickListener) {
            this.documentClickListener();
        }
    }
}

@NgModule({
    imports: [ CommonModule ],
    exports: [AutoComplete],
    declarations: [AutoComplete]
})
export class AutoCompleteModule { }
