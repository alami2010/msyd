export enum BodyOutputType {
    Default, TrustedHtml, Component
}