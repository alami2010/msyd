export class Validation {
    validations: ValidationItem[];
}

export class ValidationItem {
    type: ValidationType;
    message: string;
    regex: string;
    custom: Function;
    valid: boolean;
    range: number;

    constructor(type: ValidationType, message: string) {
        this.message = message;
        this.type = type;
    }
}

export enum ValidationType {
    REQUIRED = 1,
    MIN = 2,
    MAX = 3,
    REGEX = 4,
    CUSTOM = 5
}
