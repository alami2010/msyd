import { ViewFocusedElement } from './viewfocus.element';
import { TabItem } from './tablist.model';

export class TabElement extends ViewFocusedElement {
    tabList: TabItem[];
}
