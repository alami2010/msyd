export class BranchModel {
    id: number;
    name: string;

    constructor(id: string, name: string) {
        this.id = Number(id);
        this.name = name;
    }
}
