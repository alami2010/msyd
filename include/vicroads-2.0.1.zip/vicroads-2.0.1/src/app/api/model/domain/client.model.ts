export class ClientModel {
    id: string = '0';
    name: string;
    status: string;
    poi: string;
    dob: string;
    location: string;
}
