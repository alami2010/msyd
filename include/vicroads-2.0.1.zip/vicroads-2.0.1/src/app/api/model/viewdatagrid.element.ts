import { ViewFocusedElement } from './viewfocus.element';
export class ViewDataGridElement extends ViewFocusedElement {
    list: any[];
    rowSelect: any;
    headers: string[];
    rowProperties: string[];
}
