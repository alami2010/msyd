/**
 * Base class represents a View Data Object.
 */
export abstract class ViewModel {
    id: string;
    pristine: boolean = true;
    valid: boolean = true;
}
