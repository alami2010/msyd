import { ViewListElement } from './viewlist.element';

export class ComboBoxElement extends ViewListElement {

}
