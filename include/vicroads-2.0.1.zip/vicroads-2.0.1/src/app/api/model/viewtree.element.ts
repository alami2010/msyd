import { ViewFocusedElement } from './viewfocus.element';

export class ViewTreeElement extends ViewFocusedElement {

    constructor() {
        super();
    }
}
