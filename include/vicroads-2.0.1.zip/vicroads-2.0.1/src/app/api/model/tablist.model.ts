/**
 * Tab Item, represent a Tab with its children.
 */
export class TabItem {

    /**
     * Current route path.
     */
    rootPath: string[];

    /**
     * Title of the tab
     */
    text: string;
    /**
     * Inline help shown on mouse over.
     */
    inlineHelp: string;
    /**
     * Tab link.
     */
    uiLink: string;
    /**
     * Is tab enabled?
     */
    enabled: boolean;
    /**
     * Is tab visible?
     */
    visible: boolean;
    /**
     * Is tab active?
     * Should be changed to getter/setter?
     */
    active: boolean;
    /**
     * Tab parent.
     */
    parent: TabItem;
    /**
     * Tab children. Only 2 level are supported.
     */
    children: TabItem[];
    /**
     * Defines is that tab is activated by default.
     */
    default: boolean;

    public get cssActive(): string {
        return this.active ? 'active' : '';
    }

    // Getter does not seem to be refreshed....
    activeStr: string = '';
}
