import { ViewListElement } from './viewlist.element';
import { Validation } from './validation.model';
import { ValidationInterface } from './validation.interface';

export class ViewListValidation extends ViewListElement implements ValidationInterface {
    validation: Validation;
    pristine: boolean;
    valid: boolean;
    hasError: boolean;

    constructor() {
        super();
        this.validation = new Validation();
        this.validation.validations = [];
        this.pristine = true;
        this.hasError = false;
    }
}
