
export class RequestModel {
  /**
   * The requested viewId
   */
  viewId: string;
  /**
   * Encoded Audi information such as client IP & Mac Address.
   */
  auditInformation: string;

}
