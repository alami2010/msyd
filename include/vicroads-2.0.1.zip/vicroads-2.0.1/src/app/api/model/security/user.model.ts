import { UrlSegment } from '@angular/router';

/**
 * Immutable User class.
 */
export class UserModel {
    private _roles: string[];
    private _name: string;
    private _returnUrl: string;

    constructor(roles: string[], name: string, returnUrl: string) {
        this._roles = roles;
        this._name = name;
        this._returnUrl = returnUrl;
    }

    get roles(): string[] {
        return this._roles;
    }

    get name(): string {
        return this._name;
    }

    get returnUrl(): string {
        return this._returnUrl;
    }
}
