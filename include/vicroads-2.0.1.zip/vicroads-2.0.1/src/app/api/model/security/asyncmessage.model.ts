
export class AsyncMessage {
    code: string;
    description: string;
    severity: SeverityType;
}

export enum SeverityType {
    ERROR = 1,
    SUCCESS = 2
}
