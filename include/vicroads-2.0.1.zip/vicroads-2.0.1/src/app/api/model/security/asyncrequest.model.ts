
export class AsyncRequest<T> {
    viewId: string;
    auditInformation: string;
    data: T;
}
