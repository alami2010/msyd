export class ViewElement {

    id: string;
    visible: boolean;
    enabled: boolean;
    value: any;
    classList: string[];

    get classes(): string {
        return this.classList.join(' ');
    }

    constructor() {
        this.visible = true;
        this.enabled = true;
        this.classList = [];
    }
}
