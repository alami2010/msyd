<table width="100%">
    <tr>
        <td style="vertical-align:top">
            <img alt="VicRoads logo" src="http://158.255.100.105:8001/jneveux/vicroads_ui/raw/17a3d934499e91f5bd0b0954aa4dcef51e04ed0d/.readme_assets/vicroadsLogo.png"/>
        </td>
        <td>
            <h2>- prototype version 1.0 -</h2>
        </td>
     </tr>
    <tr>
        <td style="vertical-align:top">
            <h2> Project goals</h2>
            This prototype is targeted for architect, UI designer and UI developer.
            You need to be able to understand the following general concepts described in architecture.
            <h2>Architecture</h2>
            <ul>
                <li>Angular 2.x</li>
                <li>Webpack 2.x</li>
                <li>ECMAScript 6 (ES2015)</li>
                <li>TypeScript 2.x</li>
                <li>jQuery 2.x</li>
                <li>HTML 5</li>
                <li>CSS 3</li>
                <li>Bootstrap 3.x</li>
            </ul>
        </td>
        <td style="text-align: right;">
            <img src="http://158.255.100.105:8001/jneveux/vicroads_ui/raw/43e48378910b635a1b711a864eb6930a9960d189/.readme_assets/parkedcarsandtraffic1high.jpg"/>
        </td>
    </tr>
</table>
